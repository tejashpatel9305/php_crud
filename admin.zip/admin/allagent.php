<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday" />
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" type="text/css" href="files/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/autofill/css/autoFill.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/autofill/css/select.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/buttons/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/responsive/css/responsive.dataTables.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/select/css/select.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/icofont/css/icofont.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/pages.css">
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>
    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-8">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-6.png" class="bg-c-blue">
                  <div class="d-inline">
                    <h5>All Agents</h5>
                    <!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> --> 
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">All Agents</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                <div class="page-body">
                  	<div class="sttaf-details-box">
                        

                      <div class="row">
                          
            <?php $result=mysqli_query($conn,"select * from  agent_membership ");
				$i = 1;
					while($row=mysqli_fetch_array($result))
					{
                        $agentmembershipid=$row["agent_membership_id"];;
						
				 ?>
                        	<div class="col-md-4 col-lg-4 col-sm-4 col-xs-4">
                            	<div class="sd-box">
                                	<div class="sdbox-img">
                                    	<img src="files/assets/images/user.jpg" class="img-radius img-40 align-top" alt="">
                                        <h5><?php echo $row['full_name']; ?> </h5>
                                    </div>
                                    <hr>
                                    <div class="sdbox-text">
                                    	<ul>
                                        	<li><span> Company Name :</span> <?php echo $row['company_name']; ?> </li>
                                            <li><span> Company Address :</span> <?php echo $row['company_address']; ?></li>
                                        	<li><span> Email Id :</span> <?php echo $row['email']; ?> </li>
                                            <li><span> Contact No. :</span> <?php echo $row['phone_number']; ?>  </li>
                                            <li><span> Reg.Date :</span> 
                                           
                                            <?php echo date('j-F-Y',strtotime($row['agent_reg_date'])); ; ?>  </li>
                                            
                                            <li><span> Status :</span> <?php echo $row['agent_status']; ?> </li>
                                            <li><button type="button" name="btnview" class="" data-toggle="modal" data-target="#exampleModal">
                                            		<div class="view-button"><a> View Document </a></div>
                                                </button>
                                               </li>
                                                <input type="hidden" value="<?php echo $agentmembershipid; ?>" name="<?php $row['agent_membership_id'] ?>" >	
                                               
                                            </ul>
                                    </div>
                                </div>
                            </div>
                            <?php 
              } 
            ?>     
                        </div>

                        <div class="clearfix"></div>
                      


                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Document </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="document-box">

        	<div class="row">
            <?php $result=mysqli_query($conn,"select * from  agent_membership  where agent_membership_id='".$agentmembershipid."'");
				$i = 1;
					while($row=mysqli_fetch_array($result))
					{
						
				 ?>
                <div class="col-md-4 col-sm-4 col-lg-4 col-xs-4">
                    <img src="../agent_documents/<?php echo $row["documents"]; ?>" class="img-thumbnail">
                    <div class="download-button">
                        <a download href="../agent_documents/<?php echo $row["documents"]; ?>"> Download </a>
                    </div>
                </div>

                <?php
               
              } 
             
            ?>     
               
        	</div>
        </div>
        
      </div>
    </div>
  </div>
</div>


<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/bower_components/modernizr/js/modernizr.js"></script> 
<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/bower_components/modernizr/js/css-scrollbars.js"></script> 
<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/assets/pages/edit-table/jquery.tabledit.js"></script> 
<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/assets/pages/edit-table/editable.js"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/jquery.mCustomScrollbar.concat.min.js" type="a24b6c627f2b43fcb6f7975d-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="cc43efa12e4a50aeec298001-text/javascript" src="files/assets/js/script.js"></script> 
<script src="files/assets/js/jquery.dataTables.min.js"></script> 
<script src="files/assets/pages/data-table/js/data-table-custom.js"></script> 
<script src="files/assets/pages/data-table/js/jszip.min.js"></script> 
<script src="files/assets/pages/data-table/js/pdfmake.min.js"></script> 
<script src="files/assets/pages/data-table/js/vfs_fonts.js"></script> 

<script type="a24b6c627f2b43fcb6f7975d-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>
</body>
</html>
