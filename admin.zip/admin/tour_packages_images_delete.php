<?php

include 'connection.php';

if (isset($_REQUEST['delete']))
{
 $deleteresult=mysqli_query($conn,"SELECT * FROM tour_packages_images WHERE tour_packages_images_id = '".$_REQUEST['delete']."'");
   while($deleterow=mysqli_fetch_array($deleteresult))
   {
		$tourpackagesimagesid = $deleterow["tour_packages_images_id"];
		$tourpackagesid = $deleterow["tour_packages_id"];

   }
   unlink("../images/packages/".$_REQUEST['img']);
   mysqli_query($conn,"delete from tour_packages_images where tour_packages_images_id='".$_REQUEST['delete']."'");

}
  //echo "<NOSCRIPT><a href='edit_tourpackages.php?update='".$tourpackagesid."'>Successfully Delete. Click here if you are not redirected.</a></NOSCRIPT>";

//echo "<script>window.location='edit_tourpackages.php?update='".$tourpackagesid."'';</script>;
header('Location: edit_tourpackages.php?update='.$tourpackagesid);

	exit;
