<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday"/>
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">

<script src="http://code.jquery.com/jquery-latest.min.js"></script>


<script>
	var arrayElement = [];
	function addmore(daytitleid, titles, day_details, tourpackagesid){
	    var count=$('#multiple_fields').children().length;
	    var txtHint4=$('#multiple_fields').appendChild('<div class="row"><input type="hidden" id="sizeDetailsId" name="sizeDetailsId[]" value="'+ sizeDetailsId +'" /><div class="col-md-6"><div class="form-group"><label class="control-label">Select Size</label><div class="txtHint4" style="width:513px; border:0px solid gray;"><b>Please select Sub Category first..!</b></div></div></div><div class="col-md-3"><div class="form-group"><label class="control-label">Price</label><input type="text" id="price" name="txtprice[]" class="form-control" placeholder="Enter the Price .." value="'+prize+'" data-bvalidator="required" data-bvalidator-msg="Enter Price" /></div></div><div class="col-md-3 "> <div class="form-group"><label class="control-label">Qty</label><input type="text" id="qty" name="txtqty[]" class="form-control" placeholder="Enter the Qty .." value="'+ qty +'" data-bvalidator="required" data-bvalidator-msg="Enter Qty" /></div></div></div>');
		
	}
</script>

<style>
.container {
    position: relative;
    width: 100%;
    max-width: 400px;
}

.container img {
    width: 100%;
    height: auto;
}

.container .btn {
    position: absolute;
    top: 80%;
    left: 50%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    /*background-color: #555;*/
    color: white;
    font-size: 16px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container .btn:hover {
    background-color: black;
}
</style>
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>  

    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
       
      
<?php 
          include 'sidebar.php'; 
      ?>
      
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-8">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-1.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Tour Packages</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Tour Packages</a></li>
                    <li class="breadcrumb-item"><a href="#"> Edit Tour Packages </a></li>
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                	<div class="page-body">
                		<div class="form-group admin-form">
                    
                <?php	if(isset($_REQUEST['update']))
              { 
                $result = mysqli_query($conn,"select * from tour_packages where tour_packages_id='".$_REQUEST['update']."'");
                  
                    while($row = mysqli_fetch_array($result))
                {
                        $tourpackagesid = $row["tour_packages_id"];
                        
                }
              }?>
	


                     <form method="post" action="add_tour_packages_update.php?update=<?php echo $tourpackagesid ?>"  enctype="multipart/form-data" id="form1">
								
                                <input type="hidden" name="tourpackagesid" value=".$_REQUEST['update']." />
                                                    
                            	<div class="row">
<?php			 
$tourpackagesid="";
$packagename="";
$packageprice="";
$agentprice="";
$childprice ="";
$agentchildprice="";
$days="";
$packageimg="";
$packagedescription="";
$titles="";
$daydetails="";

$inclusion="";
$exclusion="";
$note="";
$cancelpolicy="";
$hotdeals="";
$tour_packages_date="";
$status="";


if(isset($_REQUEST['update']))
{ 
    $result=mysqli_query($conn,"select * from tour_packages where tour_packages_id='".$_REQUEST['update']."'");
    while($row=mysqli_fetch_array($result))
    {
        $tour_packages_id=$row["tour_packages_id"];
		$packageplaceid=$row["package_place_id"];
		
        $packagename=$row["package_name"];
		
        $packageprice=$row["package_price"];
        $childprice=$row["child_price"];
        $agentprice=$row["agent_price"];
        $agentchildprice=$row["agent_child_price"];
        
        $days=$row["days"];
        $packageimg=$row["tour_packages_img"];
        $packagedescription=$row["package_description"];
        $inclusion=$row["inclusion"];
        $exclusion=$row["exclusion"];
        $note=$row["note"];
        $hotdeals=$row["hot_deals"];
        $tour_packages_date=$row["tour_packages_date"];
        $status=$row["status"];
    }
}
	?>
    
    <div class="col-md-6">
                                        <label> Package Place </label>
                                       
                                       
                                        <select class="form-control" id="select_package_place"  placeholder="Select Package Place" name="txtppid" >
                                                  <?php
                                              $result4=mysqli_query($conn,"select a.*,b.* from package_place as a , tour_packages as b where a.package_place_id=b.package_place_id and  b.tour_packages_id='".$tour_packages_id."'");
                                            while($row4=mysqli_fetch_array($result4))
                                            {
                                            ?>	
                                                <option value="<?php echo $row4["package_place_id"]; ?>"><?php echo $row4["package_place_title"]; ?></option>
                                                    <?php $editcat4= $row4["package_place_id"]; ?>
                                            <?php } ?>

                                            <?php
                                              $result44=mysqli_query($conn,"select * from package_place ");
                                            while($row44=mysqli_fetch_array($result44))
                                            {
                                            ?>	
                                            <option value="<?php echo $row44["package_place_id"]; ?>"><?php echo $row44["package_place_title"]; ?></option>
                                                    <?php } ?>
                                        
                  			          </select>

                                  
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Package Place" data-valmsg-replace="true"></span>
                                    </div>
	

                                    <div class="col-md-6">
                                        <label> Package </label>
                                        <input data-val="true" data-val-number="The field PkgId must be a number." data-val-required="The PkgId field is required." id="PkgId" name="PkgId" type="hidden" value="">
                                  
                                        <input type="text" id="package_name" name="txtpackagename" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $packagename; ?>" placeholder="Package Name" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Package Name" >
                                       
                                        <span class="field-validation-valid text-danger" data-valmsg-for="PackageName" data-valmsg-replace="true"></span>
                                    </div>
                
                                   
                				</div>
                        <div class="row">
                        <div class="col-md-6">
                                        <label> Adult Price ฿ </label>
                                        <input type="text" id="package_price" name="txtpackageprice" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $packageprice; ?>" placeholder="Package Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter package price" >
                                        
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Price" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Agent Price ฿ </label>
                                        <input type="text" id="agent_price" name="txtagentprice" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentprice; ?>" placeholder="Agent Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter agent price" >
                                        
                                        <span class="field-validation-valid text-danger" data-valmsg-for="AgentPrice" data-valmsg-replace="true"></span>
                                    </div>
                				</div>

                        <div class="row">
                      
                                    <div class="col-md-6">
                                        <label>  Child Price ฿ </label>
                                        <input type="text" id="child_price" name="txtchildprice" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $childprice; ?>" placeholder="Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Child price" >
                                    
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Child Price" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Agent Child Price ฿ </label>
                                        <input type="text" id="agent_child_price" name="txtagentchildprice" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentchildprice; ?>" placeholder="Agent Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter agent Child price" >
                                    
                                        <span class="field-validation-valid text-danger" data-valmsg-for="AgentPrice" data-valmsg-replace="true"></span>
                                    </div>
                				</div>
                            	
                            	<div class="row">
                                	<div class="col-md-6">
                                        <label> Days </label>
                                       
                                        <input type="text" id="days" name="txtdays" class="form-control" data-val="true"  value="<?php echo $days; ?>" placeholder="Days" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter days" >
                                       
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Days" data-valmsg-replace="true"></span>
                                    </div>
                                    <div class="col-md-6">
                                        <label> Package Image </label>
                                    
                                 <input type="file" name="txtfile[]" class="form-control"  multiple="multiple" data-bvalidator="extension[jpg:png:JPG],required" data-bvalidator-msg="Please select file of type .jpg, .png, .JPG" >
                         
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Image" data-valmsg-replace="true"></span>
                                    </div>
                                    <input type="hidden" value="<?php echo $packageimg; ?>" name="oldimg" />
												
                              </div>
                              <label> Multiple Image </label>
                          <div class="row">
                     
                        
                                      
                                    <?php if(isset($_REQUEST['update']))
                                     {      
                                            $Mutliphotoresult=mysqli_query($conn,"SELECT * FROM tour_packages_images WHERE tour_packages_id = '".$_REQUEST['update']."'");
                                            while($photorow=mysqli_fetch_array($Mutliphotoresult))
                                            {
												$tourpackagesimagesid = $photorow['tour_packages_images_id'];
												
                                              ?>
                                              <div class="col-md-3 col-sm-6">
                                                <div class="single-package">
                                                  <div class="package-image">
                                                                <div class="container">
                                                                  <img src="../images/packages/<?php echo $photorow['tour_packages_sub_img'];?>" alt="Snow" style="width:100%; ">
																	   <br/>
                                                   
                                                                  <a href="tour_packages_images_delete.php?delete=<?php echo $photorow['tour_packages_images_id']; ?>" data-toggle="tooltip" data-original-title="Delete" class="tabledit-delete-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;" onClick="return Delprod()">Delete</a>
                                                       

                                                                
                                                                </div>   
                                                   </div>
                                                </div>
                                                </div>
							    <input type="hidden" value="<?php echo $tourpackagesimagesid; ?>" name="txttourpackagesimagesid[]" >	
                                            <?php
											
											}?>
                                              <?php } ?>  

                                               
			
                             
                                
                                <script type="text/javascript" language="javascript">
                                
                                function Delprod()
                                {
                                  return confirm("Are Sure Want To Delete?");
                                }
                                
                                </script>
                                                      
                           
                            	</div>
                                <br/>
                                <div class="row">
                                	<div class="col-md-12">
                                        <label> Description </label>
                                        <textarea class="form-control" cols="20" id="package_description" name="txtpackagedescription" placeholder="Package Overview" required rows="4" ><?php echo htmlspecialchars($packagedescription); ?></textarea>
 													   
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Description" data-valmsg-replace="true"></span>
                                    </div>
                                </div>
 							<div class="addday-btn">
                                   <button class="extra-fields-customer" id="add_more">+ Add More Day </button>
				 
                                </div>
                                <br/> <br/>
                                

<?php if(isset($_REQUEST['update']))
{ 
    $result1=mysqli_query($conn,"select a.*,b.* from day_title as a ,tour_packages as b  where a.tour_packages_id=b.tour_packages_id and a.tour_packages_id='".$_REQUEST['update']."'");
    while($row1=mysqli_fetch_array($result1))
    { 
       $daytitleid=$row1["day_title_id"];
        $tourpackagesid=$row1["tour_packages_id"];
        $titles=$row1["titles"];
        $daydetails=$row1["day_details"];
        
    ?>                       
                                <div id="multiple_fields">
                                <div class="row">
                                        <div class="col-md-4">
                                            <label> Day Title (Itinerary) </label>
                                            <input class="form-control" id="titles" name="txttitles[]" placeholder="Title" required="required" type="text" value="<?php echo $titles; ?>">
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Daytitle" data-valmsg-replace="true"></span>
                                            
                                        </div>
                                        <div class="col-md-8">
                                            <label> Details </label>
                                            <textarea class="form-control" cols="20" id="day_details" name="txtdaydetails[]" placeholder="Day Details" required rows="4" value=""><?php echo $daydetails; ?></textarea>
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span>
                                        </div>
                                </div>
                                
									  </div>
                         
                                
						  <input type="hidden" value="<?php echo $daytitleid; ?>" name="txtdaytitleId[]" >	
			
    <?php }
	} ?>
 							   
                               
                            	<div class="row">
                                    <div class="col-md-6">
                                        <label> Inclusion </label>
                                        <textarea class="form-control" cols="20" id="inclusion" name="txtinclusion" placeholder="Inclution" required rows="4" ><?php echo  htmlspecialchars($inclusion); ?></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Inclusion" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Exclusion </label>
                                        <textarea class="form-control" cols="20" id="exclusion" name="txtexclusion" placeholder="Exclution" required rows="4" ><?php echo  htmlspecialchars($exclusion); ?></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Exclusion" data-valmsg-replace="true"></span>
                                    </div>
                            	</div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <label> Note </label>
                                        <textarea class="form-control" cols="20" id="note" name="txtnote" placeholder="Note" required rows="4"><?php echo htmlspecialchars($note); ?></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Note" data-valmsg-replace="true"></span>
                                    </div>
                
                            
                                </div>
                                
                                <div class="row">
                                	<div class="col-md-4">
                                    	<div class="border-checkbox-group border-checkbox-group-danger">
                                           <input type="hidden" name="chkhotdeals" value="No" >
                                          
                                          <input type="checkbox" name="chkhotdeals" value="Yes" <?php if ($hotdeals == 'Yes') { ?> checked="checked" <?php } ?> /> 
                                        	<label class="border-checkbox-label" for="checkbox5" >Display In Hot Deals</label>
										</div>
                                    </div>
                            	</div>
                                
                                <div>
                                <input type="hidden" value="<?php echo $tour_packages_id; ?>" name="txttourpackagesid" >	
			
                                

                                    <?php if(isset($_REQUEST['update'])){ ?>
                <button type="submit" class="btn tour-form-btn" name="btnupdate"> Update </button>
                <?php } else { ?>
                <button type="submit" class="btn tour-form-btn" name="btnsubmit">Submit</button>
		      		<?php } ?>
                <input type="button" class="btn " style="margin-bottom: 0px;" value="Cancel" onClick="location='tourpackages.php'" />
                                </div>
							</form>   
     					</div>
                	</div>
              	</div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>





<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/add.js"></script>

<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>



<script type="text/javascript">

  jQuery(document).ready(function($){
	var i=1;  
	  //$('#add_more').click(function(event){
	  $('#add_more').on('click', function(event)
    {
		   i++;
		  event.preventDefault();
		   var count=$('#multiple_fields').children().length;
	      // var txtHint4=$('#multiple_fields').append('<div class="col-md-4"><label> Day Title (Itinerary) </label><input class="form-control" id="titles" name="txttitles[]" placeholder="Title" required="required" type="text" value="<?php echo $daytitle; ?>"><span class="field-validation-valid text-danger" data-valmsg-for="Daytitle" data-valmsg-replace="true"></span><div class="addday-btn"></div></div> <div class="col-md-8"> <label> Details </label><textarea class="form-control" cols="20" id="day_details" name="txtdaydetails[]" placeholder="Day Details" required rows="4" value="<?php echo $daytitledetail; ?>"></textarea><span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span></div>');
		    
		  var txtHint4=$('#multiple_fields').before('<div class="row" id="row'+i+'">  <input type="hidden" value="<?php echo $daytitleid; ?>" name="txtdaytitleId[]" >	 <div class="col-md-4"><label> Day Title (Itinerary) </label><input class="form-control" id="titles" name="txttitles[]" placeholder="Title" required="required" type="text" value="<?php echo $daytitle; ?>"><span class="field-validation-valid text-danger" data-valmsg-for="Daytitle" data-valmsg-replace="true"></span><div class="addday-btn"></div></div> <div class="col-md-8"> <label> Details </label><textarea class="form-control" cols="20" id="day_details" name="txtdaydetails[]" placeholder="Day Details" required rows="4" value="<?php echo $daytitledetail; ?>"></textarea><span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span></div></div>');
		  
      
	  });


	  
  });
</script>


</body>
</html>
