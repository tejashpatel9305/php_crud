<nav class="pcoded-navbar">
          <div class="nav-list">
            <div class="pcoded-inner-navbar main-menu">
              <!--<div class="pcoded-navigation-label">Navigation</div>-->
              <ul class="pcoded-item pcoded-left-item">
              <li class="pcoded-hasmenu"> <a href="javascript:void(0)" class="waves-effect waves-dark"> <span class="pcoded-micon"><img src="files/assets/images/logo-icon/admin-2.png"></span> <span class="pcoded-mtext">Package</span> </a>
                  <ul class="pcoded-submenu">
                  	<li class=""> <a href="package_place_master.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Package Place</span></a></li>
                    <li class="active"> <a href="tourpackages.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Tour Package</span></a></li>
                  </ul>
                </li>

            <!-- 	<li class="active"> <a href="tourpackages.php" class="waves-effect waves-dark">
                	<span class="pcoded-micon"><img src="files/assets/images/logo-icon/admin-1.png"> </span> 
                    <span class="pcoded-mtext">Tour Package</span> </a>
            	</li> -->
               
                <li class="pcoded-hasmenu"> <a href="javascript:void(0)" class="waves-effect waves-dark"> <span class="pcoded-micon"><img src="files/assets/images/logo-icon/admin-3.png"></span> <span class="pcoded-mtext">Sightseen Guide </span> </a>
                  <ul class="pcoded-submenu">
                  <li class=""> <a href="sight_seen_place_master.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Place</span>
                    <span class="pcoded-badge label label-danger">
                   
                    <?php 
                        $ss = mysqli_query($conn,"select * from sight_seen_place");
                        $sights = mysqli_num_rows($ss);
                        echo $sights;
                      ?>
                    </span>
                    
                    </a></li>
                    <li class=""> <a href="sightseen.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Sight Seen Master</span>
                    <span class="pcoded-badge label label-danger">
                   
                    <?php 
                        $s = mysqli_query($conn,"select * from sightseen");
                        $sight = mysqli_num_rows($s);
                        echo $sight;
                      ?>
                    </span>
                    
                    </a></li>
                    <li class=""> <a href="daytour.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Sight Seen</span>
                    <span class="pcoded-badge label label-danger ">
                    <?php 
                        $dt = mysqli_query($conn,"select * from day_tour");
                        $daytours = mysqli_num_rows($dt);
                        echo $daytours;
                      ?>
                    </span></a></li>
                  </ul>
                </li>
				   <li class="pcoded-hasmenu"> <a href="javascript:void(0)" class="waves-effect waves-dark"> <span class="pcoded-micon"><img src="files/assets/images/logo-icon/admin-2.png"></span> <span class="pcoded-mtext">Hot Deals</span> </a>
                  <ul class="pcoded-submenu">
                  	<li class=""> <a href="hotdeals_tourpackages.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Tour Package</span></a></li>
                    <li class=""> <a href="hotdeals_sightseen.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Sight Seen</span></a></li>
                  </ul>
                </li>
                <li class="pcoded-hasmenu"> <a href="javascript:void(0)" class="waves-effect waves-dark"> <span class="pcoded-micon"><img src="files/assets/images/logo-icon/admin-4.png"></span> <span class="pcoded-mtext">Transport Master</span> </a>
                  <ul class="pcoded-submenu">
                    <li class=""> <a href="Vehicle.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Vehicle</span></a></li>
                    <li class=""> <a href="formmaster.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">From Master</span></a></li>
                    <li class=""> <a href="tomaster.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">To Master</span></a></li>
                    <li class=""> <a href="enroutmaster.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Enrout Master</span></a></li>
                    <li class=""> <a href="transport.php" class="waves-effect waves-dark"> <span class="pcoded-mtext">Transport</span>
                    <span class="pcoded-badge label label-danger">
                   
                    <?php 
                        $r = mysqli_query($conn,"select * from transport");
                        $reg = mysqli_num_rows($r);
                        echo $reg;
                      ?>
                    </span>
                    
                    </a></li>
                  </ul>
                </li>
                <li class=" "> <a href="alluser.html" class="waves-effect waves-dark">
                	<span class="pcoded-micon"><img src="files/assets/images/logo-icon/admin-5.png"></span> 
                    <span class="pcoded-mtext">All Users</span> </a>
            	</li>
                <li class=" "> <a href="allagent.php" class="waves-effect waves-dark">
                	<span class="pcoded-micon"><img src="files/assets/images/logo-icon/admin-6.png"></span> 
                    <span class="pcoded-mtext">All Agents</span> </a>
            	</li>
               </ul>
            </div>
          </div>
        </nav>