<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday" />
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
 
  <?php 
          include 'header.php'; 
      ?>
 
    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-8">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-1.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Tour Packages</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item"> <a href="#"><i class="feather icon-home"></i></a> </li>
                    <li class="breadcrumb-item"><a href="#">Tour Packages</a> </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                <div class="page-body blog-contents-version-one pt-100 pb-70 popular-packages">
                	<div class="row">
                    	<div class="col-md-12 col-xs-12 col-sm-12 col-lg-12">
                        	<div class="add-button">
                            	<p><a href="add_tourpackages.php"><i class="fa fa-plus-circle"></i> Add Tour Packages </a></p>
                            </div>
                        </div>
                    </div>
                        <div class="row">
              
            <?php $result=mysqli_query($conn,"select * from  tour_packages limit 0,8");
				$i = 1;
					while($row=mysqli_fetch_array($result))
					{
						
				 ?>
                <div class="col-md-3 col-sm-6">
                    <div class="single-package">
                        <div class="package-image">
                            <a href="single_package.php?view=<?php echo $row['tour_packages_id']; ?>">
                                <img src="../images/packages/<?php echo $row["tour_packages_img"]; ?>" alt="" style="height:150px;">
                            </a>
                        </div>
                        <div class="package-content-p">
                            <h3><?php echo $row['package_name']; ?></h3>
                            <p> <?php echo $row['days']; ?> </p>
                            <h5> Customer Price :<span> ฿ <?php echo $row['package_price']; ?> </span> </h5>
                            <h5> Agent Price :<span> ฿ <?php echo $row['agent_price']; ?> </span> </h5>
                        </div>
                        <div class="package-calto-action-p">
                          <table>
                          <tr>
                            <td><a href="edit_tourpackages.php?update=<?php echo $row['tour_packages_id']; ?>" class="tabledit-edit-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;"> Edit
 </a></td>
                            <td>
                              <a href="?delete=<?php echo $row['tour_packages_id']; ?>&img=<?php echo $row["tour_packages_img"]; ?>" data-toggle="tooltip" data-original-title="Delete" class="tabledit-delete-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;" onClick="return Delprod()"> Delete </a></td>
                              <?php
							if(isset($_REQUEST['delete']))
							{
								unlink("../images/packages/".$_REQUEST['img']);
								mysqli_query($conn,"delete from tour_packages where tour_packages_id='".$_REQUEST['delete']."'");
              
             		mysqli_query($conn,"delete from tour_packages_images where tour_packages_id='".$_REQUEST['delete']."'");
	
	
								echo "<script>window.location='tourpackages.php';</script>";
   								exit;
								
							}
							
							
							
						?>
						
						<script type="text/javascript" language="javascript">
						
						function Delprod()
						{
							return confirm("Are Sure Want To Delete?");
						}
						
						</script>
                            </td>
                            <td><a href="single_package.php?view=<?php echo $row['tour_packages_id']; ?>" class="tabledit-edit-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;"> VIEW  </a></td>
                          </tr>
                          </table>
                            
                        </div>
                    </div>
                </div><!--end single package -->
                
        <?php 
              } 
            ?>

       
    
            </div>
            			<div class="row">
                            <div class="col-sm-12 text-center">
                                <ul class="pagination">
                                    <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a>
                                    </li>
                                    <li><a href="#">2</a>
                                    </li>
                                    <li><a href="#">3</a>
                                    </li>
                                </ul>
                            </div><!-- pagination end here -->
						</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>
<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>
</body>
</html>
