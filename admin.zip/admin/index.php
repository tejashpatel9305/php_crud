<?php
session_start();
 include 'connection.php';
 ?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday" />
<meta name="author" content="Aries Holiday" />
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/icofont/css/icofont.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/pages.css">
</head>
<body themebg-pattern="theme1">
<div class="theme-loader">
  <div class="loader-track">
    <div class="preloader-wrapper">
      <div class="spinner-layer spinner-blue">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div>
        <div class="gap-patch">
          <div class="circle"></div>
        </div>
        <div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
      <div class="spinner-layer spinner-red">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div>
        <div class="gap-patch">
          <div class="circle"></div>
        </div>
        <div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
      <div class="spinner-layer spinner-yellow">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div>
        <div class="gap-patch">
          <div class="circle"></div>
        </div>
        <div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
      <div class="spinner-layer spinner-green">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div>
        <div class="gap-patch">
          <div class="circle"></div>
        </div>
        <div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
    </div>
  </div>
</div>


<section class="signin-section">
  <div class="container">
      	

  
   	<div class="row">
    	<div class="col-md-3 col-sm-3 col-xs-12 col-lg-3"></div>
        <div class="col-md-6 col-sm-6 col-xs-12 col-lg-6">
        	<div class="text-center"> <img src="files/assets/images/logo-user.png" alt="logo.png" style="max-width:150px;"> </div>
            </br>
       
        </br>
        	<div class="column form-column signup-box">
            <?php
	  
      if(isset($_REQUEST['btnsubmit']))
    {
        $result=mysqli_query($conn,"select * from tbl_login where user_name='".$_REQUEST['u_name']."' and password='".$_REQUEST['password_a']."'") or die(mysqli_error());
        if(mysqli_num_rows($result)>0)
        {
            while($r = mysqli_fetch_array($result))
            {
                $adminname = $r['user_name'];
                $pwd = $r['password'];
                
            }	
                if($adminname==$_REQUEST['u_name'] && $pwd==$_REQUEST['password_a'])
                {
                    $_SESSION['adminame'] = $_REQUEST['u_name'];
                    
                    echo "<script>window.location='tourpackages.php';</script>";
                    
                }
        }
        else
        {
        ?>
        
            <div class="alert alert-danger alert-dismissable">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <center><?php echo "Invalid Username & Password" ?> </center></div>
        <?php
        }
    }
  
  ?>
            	<h4 class="margin-bott-20"> Admin Login </h4>
             	
                	<!--COntact Form-->
                	<div class="inner-box contact-form">
                    	
      <form class="form-horizontal form-material"   id="form1" method="post">
          
                        	<div class="row clearfix">
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-xs-12">
                                	<input type="text" class="form-control" name="u_name" id="exampleInputuname" data-bvalidator="required" placeholder=" Username/Email Id" required>
                 
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-xs-12">
                                    <input type="password" class="form-control" name="password_a" id="exampleInputpwd1" data-bvalidator="required" placeholder=" Password" required>
               
                                </div>
                                
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-xs-12">
                                	<!--<div class="text-left"><button type="submit" class="theme-btn btn-style-two">Send</button></div>-->
                                    <center>
                                        <button class="theme-btn btn-style-two" name="btnsubmit" type="submit">Sign In</button>
     
                                    </center>
                                </div>
                                
                                <!--<div class="login-bottom">
    								<p><a href="agentlogin-membership.html" class="text-center login"> Register a new membership </a></p>
                                    <p><a href="forgetpassword.html" class="text-center login"> Forget Password ? </a></p>
								</div>-->
                                
                            </div>
                        </form>
                    </div><!--COntact Form-->
                    
                </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 col-lg-3"></div>
    </div>
  </div>
</section>


<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e1afd9f43103655b7bfdcaf2-text/javascript"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/bower_components/modernizr/js/modernizr.js"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/bower_components/modernizr/js/css-scrollbars.js"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript" src="files/assets/js/common-pages.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e1afd9f43103655b7bfdcaf2-text/javascript"></script> 
<script type="e1afd9f43103655b7bfdcaf2-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e1afd9f43103655b7bfdcaf2-|49" defer=""></script>
</body>
</html>
