<?php

include 'connection.php';

$data = $_POST;

$count = count($_REQUEST['txttitles']);

$cnt = fetchsinglecol($conn, "select max(tour_packages_id) from  tour_packages");
$pid = $cnt + 1;

foreach ($_REQUEST['txttitles'] as $i => $value) {
	
    move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/packages/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
    $file = date('Ymd') . $_FILES['txtfile']['name'][$i];

    $tourpackagesdate=date("Y-m-d H:i:s");
    $checkboxhotdeals=$_POST['chkhotdeals']; 
    $packagedescription = mysqli_real_escape_string($conn,$_POST['txtpackagedescription']);
    $note = mysqli_real_escape_string($conn,$_POST['txtnote']);
	$inclusion = mysqli_real_escape_string($conn,$_POST['txtinclusion']);
	$exclusion = mysqli_real_escape_string($conn,$_POST['txtexclusion']);
	
     
    $sql = "INSERT INTO `tour_packages`(`tour_packages_id`,`package_place_id`, `package_name`, `package_price`,`child_price`, `agent_price`, `agent_child_price`, `days`, `tour_packages_img`, `package_description`, `inclusion`, `exclusion`, `note`, `hot_deals`, `tour_packages_date`, `status`) VALUES('" . $pid . "','".$_REQUEST['txtppid']."','".$_REQUEST['txtpackagename']."','".$_REQUEST['txtpackageprice']."','".$_REQUEST['txtchildprice']."','".$_REQUEST['txtagentprice']."','".$_REQUEST['txtagentchildprice']."','".$_REQUEST['txtdays']."','".$file."','".$packagedescription."','".$inclusion."','".$exclusion."','".$note."','".$checkboxhotdeals."','".$tourpackagesdate."','Y')";
   

   //echo $sql;
   // die();
    mysqli_query($conn, $sql);
}

function fetchsinglecol($conn, $query)
{
    $Q = mysqli_query($conn, $query) or die(mysqli_error());
    $data = mysqli_fetch_array($Q);
    return $data[0];

}

if (isset($_REQUEST['btnsubmit'])) {
    for ($i = 0; $i < count($_REQUEST['txttitles']); $i++) {
        $daydetails = mysqli_real_escape_string($conn,$_POST['txtdaydetails'][$i]);
        $daydata = mysqli_query($conn, "INSERT INTO `day_title` (`day_title_id`,`tour_packages_id`,`titles`,`day_details`) values (null,'" . $pid . "','" . $_REQUEST['txttitles'][$i] . "','" . $daydetails . "')") or die(mysqli_error($conn));
        //echo $daydata;
        //die();
    }

}
if (isset($_REQUEST['btnsubmit'])) {
    for ($i = 0; $i < count($_FILES["txtfile"]["name"]); $i++) {
   
        move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/packages/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
        $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
    
        $data = mysqli_query($conn, "insert into tour_packages_images(tour_packages_images_id,tour_packages_id,tour_packages_sub_img) values (null,'" . $pid . "','" . $file . "')") or die(mysqli_error($conn));
        //echo "insert into product_image(product_image_id,product_id,product_sub_img) values (null,'".$cnt."','".$filepath."')";
       // echo $data;
       // die();
    }

}

echo "<script>window.location='tourpackages.php';</script>";
exit;