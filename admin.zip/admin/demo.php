<html>
    <head>
    <script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script>
    $(document).ready(function(){

        $( "#plus" ).on("click", function() {

            $( "#frmfeed" ).append( '<input type="text" name="country[]" class="form-control oditek-form" placeholder="Add Country"/>');

        });

        $("#minus").on("click", function(){

           if($("input[name='country[]']").length > 1)
           {
              $("input[name='country[]']:eq("+(length-1)+")").remove();
           }

        });

        $("#btnsubmit").on("click", function(){

            var countries = []; 
            $("input[name='country[]']").each(function(){

                countries.push($(this).prop("value"));

            });

            console.log(countries);

            //AJAX Post Data To Your Server

            var postDataObj = {
                            url: "YOUR_SERVER_FILE",
                            type: "post",
                            data: countries,
                            success: function(data){
                               //Response Data From Server
                            }
            }
            console.log(postDataObj);       

            $.ajax(postDataObj);



        });

    });
    </script>

    

<script type="text/javascript">

jQuery(document).ready(function($){
  
    //$('#add_more').click(function(event){
    $('#add_more').on('click', function(event)
  {
        
        event.preventDefault();
         var count=$('#multiple_fields').children().length;
         var txtHint4=$('#multiple_fields').append('<div class="col-md-4"><label> Day Title (Itinerary) </label><input class="form-control" id="titles" name="txttitles[]" placeholder="Title" required="required" type="text" value="<?php echo $daytitle; ?>"><span class="field-validation-valid text-danger" data-valmsg-for="Daytitle" data-valmsg-replace="true"></span><div class="addday-btn"><button class="extra-fields-customer" id="add_more">+ Add More Day </button></div></div> <div class="col-md-8"> <label> Details </label><textarea class="form-control" cols="20" id="day_details" name="txtdaydetails[]" placeholder="Day Details" required rows="4" value="<?php echo $daytitledetail; ?>"></textarea><span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span></div>');
        
    
    });


    
});
</script>

    </head>
    <body>


     <form name="frmfeed" id="frmfeed" enctype="multipart/form-data" method="post" onSubmit="return validateFeedbackForm();">
       <input type="text" name="country[]" id="con" class="form-control oditek-form" placeholder="Add Country"><br/><br/>
    </form>

    <input type="button" class="btn btn-success" name="plus" id="plus" value="+"> <input type="button" class="btn btn-danger" name="minus" id="minus" value="-">
    <button type="submit" class="btnsub" name="userbtnsubmit" id="btnsubmit">Add</button>


    <div id="multiple_fields">
                                <div class="row">
                                        <div class="col-md-4">
                                            <label> Day Title (Itinerary) </label>
                                            <input class="form-control" id="titles" name="txttitles[]" placeholder="Title" required="required" type="text" >
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Daytitle" data-valmsg-replace="true"></span>
                                            <div class="addday-btn">
                                                <button class="extra-fields-customer" id="add_more">+ Add More Day </button>
				 
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <label> Details </label>
                                            <textarea class="form-control" cols="20" id="day_details" name="txtdaydetails[]" placeholder="Day Details" required rows="4" ></textarea>
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span>
                                        </div>
                                </div>
                                </div>
    </body>
    </html>