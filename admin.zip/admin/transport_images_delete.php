<?php

include 'connection.php';

if (isset($_REQUEST['delete']))
{
 $deleteresult=mysqli_query($conn,"SELECT * FROM transport_image where transport_image_id = '".$_REQUEST['delete']."'");
   while($deleterow=mysqli_fetch_array($deleteresult))
   {
		$transportimageid = $deleterow["transport_image_id"];
		$transportid = $deleterow["transport_id"];

   }
   unlink("../images/transport/".$_REQUEST['img']);
   mysqli_query($conn,"delete from transport_image where transport_image_id ='".$_REQUEST['delete']."'");

}
  //echo "<NOSCRIPT><a href='edit_tourpackages.php?update='".$tourpackagesid."'>Successfully Delete. Click here if you are not redirected.</a></NOSCRIPT>";

//echo "<script>window.location='edit_tourpackages.php?update='".$tourpackagesid."'';</script>;
header('Location: edit_transport.php?update='.$transportid);

	exit;
