<?php

include 'connection.php';

$data = $_POST;

$count = count($_FILES["txtfile"]["name"]);

$cnt = fetchsinglecol($conn, "select max(sightseen_id) from sightseen");
$pid = $cnt + 1;

foreach ($_FILES["txtfile"]["name"] as $i => $value) {
	
 //   move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/sightseen/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
   // $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
    $sightseendate=date("Y-m-d H:i:s");
   
    $sql = "update sightseen  set sightseen_title='".$_REQUEST['txtsightseentitle']."',sight_seen_place_id='".$_REQUEST['txtssid']."',sightseen_details ='".$_REQUEST['txtsightseendetails']."', sightseen_date ='".$sightseendate."', status = 'Y' where sightseen_id = '".$_REQUEST['update']."'";
   
	//echo $sql;
    //die();
    mysqli_query($conn, $sql);
}

function fetchsinglecol($conn, $query)
{
    $Q = mysqli_query($conn, $query) or die(mysqli_error());
    $data = mysqli_fetch_array($Q);
    return $data[0];

}

if($_FILES["txtfile"]["name"] !='')
{
    echo "<script>window.location='sightseen.php';</script>";
}
elseif (isset($_REQUEST['btnupdate']) && isset($_FILES["txtfile"]["name"]) ) 
{
    for ($i = 0; $i < count($_FILES["txtfile"]["name"]); $i++) {
   
        move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/sightseen/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
        $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
    
      
           $data = mysqli_query($conn, "insert into sightseen_images(sightseen_images_id,sightseen_id,sightseen_package_sub_img) values (null,'" . $_REQUEST['update'] . "','" . $file . "')") or die(mysqli_error($conn));
      
    }
}

    
echo "<script>window.location='sightseen.php';</script>";
exit;