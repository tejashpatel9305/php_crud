<?php

include 'connection.php';


$p=$_REQUEST["p"];

$sem_sql="SELECT a.*,b.* FROM day_tour as a ,sightseen as b WHERE a.sightseen_id=b.sightseen_id and a.day_tour_id ='$p' ";
$sem_result = mysqli_query($conn,$sem_sql);

$sem_html = "<select name='select_title' class='form-control' id='select_title'>";
//$sem_html .= "<option value=''>select</option>";
while($sem_row = mysqli_fetch_array($sem_result))
{
	$id=$sem_row['sightseen_id'];
	$sem_html .= "<option value='$id'>" . $sem_row['sightseen_title'] . "</option>";
}



/*
$q=$_REQUEST["q"];
$sem_sql="SELECT * FROM sightseen WHERE sightseen_id ='$q'";
$sem_result = mysqli_query($conn,$sem_sql);


while($sem_row = mysqli_fetch_array($sem_result))
{
	$id=$sem_row['sightseen_id'];
	$sem_html .= "<option value='$id'>" . $sem_row['sightseen_title'] . "</option>";
}*/
$sem_html .= "</select>";
$resp['sem'] = $sem_html;



echo json_encode($resp);

exit;
 
mysqli_close($conn);
?>



