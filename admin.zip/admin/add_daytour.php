<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday"/>
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
<script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>
    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-5">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-1.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Tour Guide Master</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-7">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Tour Guide Master</a></li>
                    <li class="breadcrumb-item"><a href="#"> Day Tour </a></li>
                    <li class="breadcrumb-item"><a href="#"> Add Day Tour </a></li>
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                	<div class="page-body">
                		<div class="form-group admin-form">
                        <form method="post" action="add_day_tour_insert.php" enctype="multipart/form-data" id="form1">
						<?php			 
$daytourid="";
$sightseenplaceid="";
$durationtitle="";
$showtime="";
$seattypeid="";
$transferid="";

$adultprice="";
$childprice="";
$agentadultprice="";
$agentchildprice="";


$description="";
$inclusion="";
$exclusion="";
$daytitle="";
$daytourimg="";
$daytourdate="";
$status="";

?>
                            <div class="row">
                                    <div class="col-md-6">
                                        <label> Place </label>
                                        <input data-val="true" data-val-number="The field PkgId must be a number." data-val-required="The PkgId field is required." id="PkgId" name="PkgId" type="hidden" value="">
                                        
                                        <select class="form-control" id="select_place"   placeholder="Select Sight Seen Place" name="txtptid" required="required">
                                            <option value="">Select Place</option>
                                            <?php
                                                    $result2=mysqli_query($conn,"select * from sight_seen_place");
                                                while($row2=mysqli_fetch_array($result2))
                                                {
                                                ?>	
                                                <option value="<?php echo $row2["sight_seen_place_id"]; ?>"><?php echo $row2["sight_seen_place_title"]; ?></option>
                                            <?php } ?>
                                            
                                            </select>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="place" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Sightseen </label>
                                        <div id="txtHint1" style="width:450px; border:0px solid gray;">
					
                                                <b>Please select Place first..!</b>		
                                            </div>
                                        <!--<select class="form-control" data-val="true" data-val-number="The field Sightseen must be a number." id="Sightseen" name="Sightseen" required><option value="">--select Sightseen--</option>
                                            <option value="1">Phi Phi Island By Big Boat</option>
                                            <option value="2">James Bond Island</option>
                                            <option value="4">Coral Island </option>
                                            <option value="5">Nong Nooch Tropical Botanical Garden</option>
                                            <option value="6">Under Water World</option>
                                            <option value="7">Tiger Park</option>
                                            <option value="8">Frost Magical Ice of Siam</option>
                                            <option value="9">4 Island By Speed Boat</option>
                                            <option value="16">Safari World Marin Park With Lunch</option>
                                            <option value="18">Dream World</option>
                                            <option value="20">Phuket City Tour</option>
                                            <option value="21">Dolphin Show</option>
                                            <option value="22">Tiger Kigndom</option>
                                            <option value="23">Pattaya Floating Market</option>
                                            <option value="24">Mini Siam</option>
                                            <option value="25">Alcazar Show</option>
                                            <option value="26">Tiffany’s Show</option>
                                            <option value="27">Colosseum Cabaret Show</option>
                                            <option value="28">Sanctuary of Truth</option>
                                            <option value="29">Khao Kheow Open Zoo</option>
                                            <option value="1023">Art in Paradise</option>
                                            <option value="1024">Art in Paradise</option>
                                            <option value="1025">Teddy Bear Museum</option>
                                            <option value="1026">Swiss Sheep Farm</option>
                                            <option value="1027">Flight of the Gibbon</option>
                                            <option value="1028">Bungy Jump</option>
                                            <option value="1029">Ramayana Water Park</option>
                                            <option value="1030">Phi Phi Island by speed boat </option>
                                            <option value="1031">James Bond Island by Speed boat</option>
                                            <option value="1032">James bond by big boat </option>
                                            <option value="1033">big buddha </option>
                                            <option value="1034">4 Island by speed boat</option>
                                            <option value="1035">Ripley’s Believe It or Not!</option>
                                            <option value="1036">Cartoon Network Amazone Water Park</option>
                                            <option value="1037">Siam Niramit Cultural Show</option>
                                            <option value="1038">Chaophraya Dinner Cruise</option>
                                            <option value="1039">Siam Park City</option>
                                            <option value="1040">Sea Life Ocean World</option>
                                            <option value="1041">Madame Tussauds</option>
                                            <option value="1042">Bangkok City Tour</option>
                                            <option value="1043">Simon Cabaret Show</option>
                                            <option value="1044">Splash Jungle Water Park</option>
                                            <option value="1045">Phuket Fantasea Show</option>
                                            <option value="1046">Siam Niramit Show</option>
                                            <option value="1047">4 Island Tour Long Tail Boat</option>
                                            <option value="1049">Kayak Discovery Tour in Tha Lane Bay</option>
                                            <option value="1050">Phi Phi Island Speed Boat Tour  from Krabi</option>
                                            <option value="1051">Hong Islands Longboat Tour &amp; Lunch </option>
                                            <option value="1052">Krabi Hot Springs</option>
                                            <option value="2051">Phi Phi Maiton Khai</option>
										</select>-->
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Sightseen" data-valmsg-replace="true"></span>
                                    </div>
                
                                   <!-- <div class="col-md-4">
                                        <label> Tour Type </label>
                                        <select class="form-control" id="Type" name="Type" required><option value="">Select Tour Type</option>
                                            <option>Half Day Tour</option>
                                            <option>Full Day Tour</option>
                                            <option>Night Tour</option>
                                            <option>Single Tour</option>
                                            <option>Combo Tour</option>
                                            <option>Day Tour</option>
										</select>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Type" data-valmsg-replace="true"></span>
                                    </div>-->
                				</div>
                            <!--	<div id="multiple_fields">
                                
                            	<div class="row">
                                	<div class="col-md-5">
                                        <label> Duration (Ex. 1 Hour,5 Hour....)</label>
                                        <input type="text" id="duration_title" name="txtdurationtitle[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $durationtitle; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" >
                                       <span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span>
                                    </div>
                                	<div class="col-md-5">
                                        <label> Show Time  </label>
                                        <input type="text" id="show_time" name="txtshowtime[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $showtime; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" >
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span>
                                    </div>
                                   
                                    <div class="col-md-2">
                                    	<div class="addday-btn-two">
                                   			<a href="#" class="extra-fields-customer" id="add_more"> + Add More </a>
                                     	</div>
                                    </div>
                                </div>
                                </div>-->
                                <div class="table-responsive">
                                  <table class="table table-bordered" id="dynamic_field">
                                  <tr>
                                  <td>
                                      <label> Duration (Ex. 1 Hour,5 Hour....)</label>
                                      <input type="text" id="duration_title" name="txtdurationtitle[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $durationtitle; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" >
                                      <span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span>
                              
                                    </td>
                                  <td>
                                  
                                     <label> Show Time  </label>
                                      <input type="text" id="show_time" name="txtshowtime[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $showtime; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" >
                                      <span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span>
                                
                                    </td>
                                 
                                  <td>
                                      <div class="col-md-2">
                                    	<div class="addday-btn-two">
                                   			<a href="#" class="extra-fields-customer" id="add" name="add"> + Add More </a>
                                     	</div>
                                    </div>
                                  </tr>
                                  </table>
                                  
                              </div>
                              <div id="multiple_fields_price">
                             
                                <div class="row">
                                	 <div class="col-md-6">
                                        <label> Package Type </label>
                                        
                                        <select class="form-control" id="select_seat_type"   placeholder="Select Package Type" name="txtstid[]" required="required">
                                            <option value="">Select Package Type</option>
                                            <?php
                                                    $result=mysqli_query($conn,"select * from seat_type");
                                                while($row=mysqli_fetch_array($result))
                                                {
                                                ?>	
                                                <option value="<?php echo $row["seat_type_id"]; ?>"><?php echo $row["seat_type_title"]; ?></option>
                                            <?php } ?>
                                            
                                            </select>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Type" data-valmsg-replace="true"></span>
                                    </div>
                                	<div class="col-md-6">
                                        <label> Transfer </label>
                                       
                                        <select class="form-control" id="select_transfer"   placeholder="Select Transfer" name="txttid[]" required="required">
                                            <option value="">Select Transfer</option>
                                            <?php
                                                    $result1=mysqli_query($conn,"select * from transfer");
                                                while($row1=mysqli_fetch_array($result1))
                                                {
                                                ?>	
                                                <option value="<?php echo $row1["transfer_id"]; ?>"><?php echo $row1["transfer_title"]; ?></option>
                                            <?php } ?>
                                            
                                            </select>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Type" data-valmsg-replace="true"></span>
                                    </div>
                                </div>
                                
                             
                                <div class="row">
                                	<div class="col-md-2">
                                      <label>	Adult Price in ฿ </label>
                                      <input type="text" id="adult_price" name="txtadultprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $adultprice; ?>" placeholder="Adult Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Adult Price" >                                          
                                      <span class="field-validation-valid text-danger" data-valmsg-for="AdultPrice" data-valmsg-replace="true"></span>
                                  </div>
                                    <div class="col-md-2">
                                        <label>	Child Price in ฿ </label>
                                        <input type="text" id="child_price" name="txtchildprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $childprice; ?>" placeholder="Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Child Price" >                                          
                                        <span class="field-validation-valid text-danger" data-valmsg-for="ChildPrice" data-valmsg-replace="true"></span>
                                    </div>
                                	<div class="col-md-3">
                                        <label>Agent Adult Price in ฿ </label>
                                        <input type="text" id="agent_adult_price" name="txtagentadultprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentadultprice; ?>" placeholder="Agent Adult Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Adult Price" >                                          
                                        <span class="field-validation-valid text-danger" data-valmsg-for="AgAdultPrice" data-valmsg-replace="true"></span>
                                  </div>
                                    <div class="col-md-3">
                                        <label>Agent Child Price in ฿ </label>
                                        <input type="text" id="agent_child_price" name="txtagentchildprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentchildprice; ?>" placeholder="Agent Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Child Price" >                                         
                                        <span class="field-validation-valid text-danger" data-valmsg-for="AgChildPrice" data-valmsg-replace="true"></span>
                    				      </div>
                                    <div class="col-md-2">
                                    	<div class="addday-btn-two">
                                   			<a href="#" class="extra-fields-customer" id="add_more_price"> + Add New </a>
                                     	</div>
                                    </div>
                            	 </div>
                                </div>
                                <div class="row">
                                	<div class="col-md-4">
                                        <label> Description </label>
                                        <textarea class="form-control" cols="20" id="Description" name="txtdescription" placeholder="Overview" required rows="4"></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Description" data-valmsg-replace="true"></span>
                                    </div>
                                    <div class="col-md-4">
                                        <label> Inclusions </label>
                                        <textarea class="form-control" cols="20" id="Inclusions" name="txtinclusions" placeholder="Inclusions" required rows="4"></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Inclusions" data-valmsg-replace="true"></span>
                                    </div>
                                    <div class="col-md-4">
                                        <label> Exclusions </label>
                                        <textarea class="form-control" cols="20" id="Exclusions" name="txtexclusions" placeholder="Exclusions" required rows="4"></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Exclusions" data-valmsg-replace="true"></span>
                                    </div>
                                </div>
                                
                                <div class="row">
                                        <div class="col-md-4">
                                            <label> Day Title (Itinerary) </label>
                                            <input class="form-control" id="day_title" name="txtdaytitle" placeholder="Day Title" required="required" type="text" value="">
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Day title" data-valmsg-replace="true"></span>
                                           <!-- <div class="addday-btn">
                                                <a href="#" class="extra-fields-customer"> + Add More Day </a>
                                            </div>-->
                                        </div>
                                        <!--<div class="col-md-8">
                                            <label> Details </label>
                                            <textarea class="form-control" cols="20" id="Details" name="Details" placeholder="Day Details" required rows="4"></textarea>
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span>
                                        </div>-->
                                        <div class="col-md-8">
                                            <label> Image </label>
                                            <input type="file" name="txtfile[]" class="form-control"  multiple="multiple" data-bvalidator="extension[jpg:png:JPG],required" required="required"  data-bvalidator-msg="Please select file of type .jpg, .png, .JPG" >
                                               <span class="field-validation-valid text-danger" data-valmsg-for="Image" data-valmsg-replace="true"></span>
                                    	</div>
                                </div>
                                
                                <div class="row">
                                	<div class="col-md-4">
                                    	<div class="border-checkbox-group border-checkbox-group-danger">
                                           <input type="hidden" name="chkhotdeals" value="No">
                                        	<input class="border-checkbox" type="checkbox" name ="chkhotdeals"  value="Yes">
                                        	<label class="border-checkbox-label" for="checkbox5" >Display In Hot Deals</label>
										</div>
                                    </div>
                            	</div>
                              <input type="hidden" value="<?php echo $daytourid; ?>" name="txtdaytourid" >	
			
                                   
                                <div>
                                <div class="form-actions">

                                <?php if(isset($_REQUEST['update'])){ ?>
                <button type="submit" class="btn tour-form-btn" name="btnupdate"> Update </button>
                <?php } else { ?>
                <button type="submit" class="btn tour-form-btn" name="btnsubmit">Submit</button>
		      		<?php } ?>
                <input type="button" class="btn " style="margin-bottom: 0px;" value="Cancel" onClick="location='daytour.php'" />
                              
                              </div>
							</form>   
     					</div>
                	</div>
              	</div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>
<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/add.js"></script>

<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>

<script>
      $(document).ready(function(){
        var i=1;
        $('#add').click(function(){
        i++;
        $('#dynamic_field').append('<tr id="row'+i+'"><td><label> Duration (Ex. 1 Hour,5 Hour....)</label><input type="text" id="duration_title" name="txtdurationtitle[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $durationtitle; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" > <span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span></td><td> <label> Show Time  </label><input type="text" id="show_time" name="txtshowtime[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $showtime; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" >  <span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span></td><td> <div class="col-md-2"><br/><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">Remove</button></div></td></tr>');
        });
        
      $(document).on('click', '.btn_remove', function(){
      var button_id = $(this).attr("id"); 
      $('#row'+button_id+'').remove();
        });
      });
</script>

<script type="text/javascript">

  jQuery(document).ready(function($){
	
	  //$('#add_more').click(function(event){
	  $('#add_more').on('click', function(event)
    {
		  
		  event.preventDefault();
		   var count=$('#multiple_fields').children().length;
	       var txtHint4=$('#multiple_fields').append(' <div class="row"><div class="col-md-5"><label> Duration(Ex. 1 Hour,5 Hour....) </label><input type="text" id="duration_title" name="txtdurationtitle[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $durationtitle; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" > <span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span></div><div class="col-md-5"><label> Show Time </label> <input type="text" id="show_time" name="txtshowtime[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $showtime; ?>" placeholder="Time" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Time" ><span class="field-validation-valid text-danger" data-valmsg-for="Time" data-valmsg-replace="true"></span></div><div class="col-md-2"><div class="addday-btn-two"><a href="#" class="extra-fields-customer" id="remove_price">  Remove </a></div></div></div>');  
	  });
    
 


  });
</script>

<script type="text/javascript">

  jQuery(document).ready(function($){
	
	  //$('#add_more').click(function(event){
	  $('#add_more_price').on('click', function(event)
    {
		  
		  event.preventDefault();
		   var count=$('#multiple_fields_price').children().length;
	       var txtHint4=$('#multiple_fields_price').append('<hr><div class="row"><div class="col-md-6"><label> Package Type </label><select class="form-control" id="select_seat_type"   placeholder="Select Package Type" name="txtstid[]" required> <option  value="">Select Package Type</option>  <?php  $result=mysqli_query($conn,"select * from seat_type"); while($row=mysqli_fetch_array($result)){?><option value="<?php echo $row["seat_type_id"]; ?>"><?php echo $row["seat_type_title"]; ?></option><?php } ?></select><span class="field-validation-valid text-danger" data-valmsg-for="Type" data-valmsg-replace="true"></span></div><div class="col-md-6"><label> Transfer </label><select class="form-control" id="select_transfer"   placeholder="Select Transfer" name="txttid[]" required><option  value="">Select Transfer</option> <?php $result1=mysqli_query($conn,"select * from transfer"); while($row1=mysqli_fetch_array($result1)){?><option value="<?php echo $row1["transfer_id"]; ?>"><?php echo $row1["transfer_title"]; ?></option> <?php } ?> </select> <span class="field-validation-valid text-danger" data-valmsg-for="Type" data-valmsg-replace="true"></span></div> </div></div>  <div class="row"><div class="col-md-2"> <label>	Adult Price in ฿ </label><input type="text" id="adult_price" name="txtadultprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $adultprice; ?>" placeholder="Adult Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Adult Price" ><span class="field-validation-valid text-danger" data-valmsg-for="AdultPrice" data-valmsg-replace="true"></span></div><div class="col-md-2"><label>	Child Price in ฿ </label> <input type="text" id="child_price" name="txtchildprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $childprice; ?>" placeholder="Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Child Price" ><span class="field-validation-valid text-danger" data-valmsg-for="ChildPrice" data-valmsg-replace="true"></span></div><div class="col-md-3"><label>Agent Adult Price in ฿ </label><input type="text" id="agent_adult_price" name="txtagentadultprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentadultprice; ?>" placeholder="Agent Adult Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Adult Price" ><span class="field-validation-valid text-danger" data-valmsg-for="AgAdultPrice" data-valmsg-replace="true"></span></div><div class="col-md-3"><label>Agent Child Price in ฿ </label><input type="text" id="agent_child_price" name="txtagentchildprice[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentchildprice; ?>" placeholder="Agent Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Child Price" ><span class="field-validation-valid text-danger" data-valmsg-for="AgChildPrice" data-valmsg-replace="true"></span></div></div>');
      
	  });


	  
  });
</script>


<script type="text/javascript">

$(document).ready(function () 
{ 
	
    $('.showsource').each(function(){
		var id = $(this).attr('id');
		var source = $('#' + id + 'v').html();
		$('#' + id).text(source); 
	});

	$('body').on('change','select#select_place',function()
	{
		if($(this).prop('value') != "" || $(this).prop('value') != null || $(this).prop('value') != "undefined" )
		{
			$.when(
			$.post("Get_asign_place.php",
				{
					q:$(this).prop('value')
				},
				function( data )
				{
					var obj = JSON.parse( data );
					$("#txtHint1").html(obj.sem);
					
				}
			)
			);
		}
	});
});
	</script>
	
</body>
</html>
