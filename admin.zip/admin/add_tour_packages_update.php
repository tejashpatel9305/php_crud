<?php

include 'connection.php';

$data = $_POST;

$count = count($_REQUEST['txttitles']);

$cnt = fetchsinglecol($conn, "select max(tour_packages_id) from tour_packages");
$pid = $cnt + 1;

foreach ($_REQUEST['txttitles'] as $i => $value) {
	
    //move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/packages/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
   // $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
   
	$checkboxhotdeals=$_POST['chkhotdeals']; 
	 $tourpackagesdate=date("Y-m-d H:i:s");
	
	$packagedescription = mysqli_real_escape_string($conn,$_REQUEST['txtpackagedescription']);
    $note = mysqli_real_escape_string($conn,$_REQUEST['txtnote']);
    $inclusion = mysqli_real_escape_string($conn,$_REQUEST['txtinclusion']);
  	$exclusion = mysqli_real_escape_string($conn,$_REQUEST['txtexclusion']);

    $sql = "update tour_packages  set  package_place_id ='".$_REQUEST['txtppid']."', package_name ='".$_REQUEST['txtpackagename']."', package_price='".$_REQUEST['txtpackageprice']."', child_price ='".$_REQUEST['txtchildprice']."', agent_price ='".$_REQUEST['txtagentprice']."', agent_child_price ='".$_REQUEST['txtagentchildprice']."', days ='".$_REQUEST['txtdays']."',  package_description ='".$packagedescription."', inclusion='".$inclusion."', exclusion='" . $exclusion. "', note='".$note."', 	hot_deals='".$checkboxhotdeals."', 	tour_packages_date='".$tourpackagesdate."', status ='Y' where tour_packages_id = '".$_REQUEST['update']."'";
   
	//echo $sql;
   // die();
    mysqli_query($conn, $sql);
}

function fetchsinglecol($conn, $query)
{
    $Q = mysqli_query($conn, $query) or die(mysqli_error());
    $data = mysqli_fetch_array($Q);
    return $data[0];

}

if (isset($_REQUEST['btnupdate'])) {
    $datadaydelete = mysqli_query($conn, "delete from day_title  where tour_packages_id ='".$_REQUEST['update']."' ");

	for ($i = 0; $i < count($_REQUEST['txttitles']); $i++) {
  			
      $daydetails = mysqli_real_escape_string($conn,$_POST['txtdaydetails'][$i]);

        $dataday = mysqli_query($conn, "insert into day_title (day_title_id,tour_packages_id,titles,day_details) values (null,'" . $_REQUEST['update'] . "','" . $_REQUEST['txttitles'][$i]. "','" . $daydetails . "')") or die(mysqli_error($conn));

		//  echo $dataday;
		 // die();
      
       
    }

}
	if (isset($_REQUEST['btnupdate']) )
	{
		for ($i = 0; $i < count($_FILES["txtfile"]["name"]); $i++) {
		if (!empty($_FILES['txtfile']['tmp_name'][$i]))
			{
			move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/packages/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
			$file = date('Ymd') . $_FILES['txtfile']['name'][$i];

			$data = mysqli_query($conn, "insert into tour_packages_images(tour_packages_images_id,tour_packages_id,tour_packages_sub_img) values (null,'" . $_REQUEST['update'] . "','" . $file . "')") or die(mysqli_error($conn));
			}
		}

	}


    
echo "<script>window.location='tourpackages.php';</script>";
exit;