<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>



<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday" />
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" type="text/css" href="files/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/autofill/css/autoFill.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/autofill/css/select.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/buttons/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/responsive/css/responsive.dataTables.css">
<link rel="stylesheet" type="text/css" href="files/assets/pages/data-table/extensions/select/css/select.dataTables.min.css">

<link rel="stylesheet" type="text/css" href="files/assets/icon/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/icofont/css/icofont.css">
<link rel="stylesheet" type="text/css" href="files/assets/icon/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/pages.css">

</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>
    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-8">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-4.png" class="bg-c-blue">
                  <div class="d-inline">
                    <h5>Transport Master</h5>
                    <!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> --> 
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Transport Master</a></li>
                    <li class="breadcrumb-item"><a href="#">Enrout Master</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                <div class="">
                  <div class="card">
                    <div class="card-block">
                     <div class="row">
                    	<div class="col-md-12 col-xs-12 col-sm-12 col-lg-12">
                        	<div class="add-button">
                            	<p><a href="add_enrout.php"><i class="fa fa-plus-circle"></i> Add Enrout Master </a></p>
                            </div>
                        </div>
                     </div>
                    
                      <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="example-2">
                          <thead>
                            <tr>
                              <th>Id</th>
                              <th>Enrout</th>
                              <th>Status</th>
                              <th class="tabledit-toolbar-column">Edit</th>
                            </tr>
                          </thead>
                          <tbody>
                          <?php $result=mysqli_query($conn,"select * from  enrout");
				  	$i = 1;
					while($row=mysqli_fetch_array($result))
					{
				 ?>
                            <tr>
                              <th scope="row">
                                  <?php 
									echo $row["enrout_id"]; 
                                ?> 
                              </th>
                              <td class="tabledit-view-mode">
                                  <span class="tabledit-span">
                                  <?php echo $row["enrout_name"]; ?>
                                </span>
                                </td>
                                <td>
                                    <?php 
                                if($row["status"]=="Y") 
                                {?>
                                <a href="?id=<?php echo $row['enrout_id']; ?>&status=<?php echo $row['status']; ?>"><span class="label label-rouded label-success pull-center">Yes</span></a>
                                <?php } else { ?>
                                <a href="?id=<?php echo $row['enrout_id']; ?>&status=<?php echo $row['status']; ?>"><span class="label label-rouded label-danger pull-center">No</span></a>
                                <?php } ?>
                                </td>
                              <td style="white-space: nowrap; width: 1%;"><div class="tabledit-toolbar btn-toolbar" style="text-align: left;">
                                  <div class="btn-group btn-group-sm" style="float: none;">

                                     <a href="add_enrout.php?update=<?php echo $row['enrout_id']; ?>" data-toggle="tooltip" data-original-title="Edit" class="tabledit-edit-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;"><span class="icofont icofont-ui-edit"></span> </a>
				                	<a href="?delete=<?php echo $row['enrout_id']; ?>" data-toggle="tooltip" data-original-title="Delete" class="tabledit-delete-button btn btn-danger waves-effect waves-light" style="float: none;margin: 5px;" onClick="return Delcat()"> <span class="icofont icofont-ui-delete"></span> </a>
						
                                  </div>
                                     
                         	  </td>
                            </tr>
                            <?php } ?>


                            <?php
							if(isset($_REQUEST['delete']))
							{
								mysqli_query($conn,"delete from enrout where enrout_id='".$_REQUEST['delete']."'");
	
								echo "<script>window.location='enroutmaster.php';</script>";
   								exit;
							}
						
							if(isset($_REQUEST["status"]))
								{
									if($_REQUEST['status']=="N")
									{
										mysqli_query($conn,"update  enrout set status='Y' where enrout_id='".$_REQUEST['id']."'");
										
										echo "<script>window.location='enroutmaster.php';</script>";
   										exit;
									}
									else
									{
										mysqli_query($conn,"update  enrout set status='N' where enrout_id='".$_REQUEST['id']."'");
										
										echo "<script>window.location='enroutmaster.php';</script>";
   										exit;
									}
								}
							?>							
							
						<script type="text/javascript" language="javascript">
						function Delcat()
						{
							return confirm("Are Sure Want To Delete?");
						}
						
						</script>
				  
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>
<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 


<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 

<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/bower_components/modernizr/js/modernizr.js"></script>
<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/bower_components/modernizr/js/css-scrollbars.js"></script>

<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/assets/pages/edit-table/jquery.tabledit.js"></script>
<script type="a24b6c627f2b43fcb6f7975d-text/javascript" src="files/assets/pages/edit-table/editable.js"></script>

<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script>
<script src="files/assets/js/jquery.mCustomScrollbar.concat.min.js" type="a24b6c627f2b43fcb6f7975d-text/javascript"></script>
 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="cc43efa12e4a50aeec298001-text/javascript" src="files/assets/js/script.js"></script>
 
<script src="files/assets/js/jquery.dataTables.min.js"></script> 
<script src="files/assets/pages/data-table/js/data-table-custom.js"></script> 
<script src="files/assets/pages/data-table/js/jszip.min.js"></script> 
<script src="files/assets/pages/data-table/js/pdfmake.min.js"></script> 
<script src="files/assets/pages/data-table/js/vfs_fonts.js"></script> 
<script src="files/assets/pages/data-table/extensions/autofill/js/dataTables.autoFill.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/autofill/js/dataTables.select.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/autofill/js/extensions-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/buttons/js/buttons.colVis.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/buttons/js/buttons.flash.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/buttons/js/dataTables.buttons.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/buttons/js/extension-btns-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/buttons/js/jszip.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/buttons/js/pdfmake.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/colreorder/js/colreorder-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/colreorder/js/dataTables.colReorder.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/fixed-colums/js/dataTables.fixedColumns.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/fixed-colums/js/fixed-column-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/fixed-header/js/dataTables.fixedHeader.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/fixed-header/js/fixed-header-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/key-table/js/dataTables.keyTable.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/key-table/js/key-table-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/responsive/js/dataTables.responsive.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/responsive/js/responsive-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/row-reorder/js/dataTables.rowReorder.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/row-reorder/js/row-reorder-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/scroller/js/dataTables.scroller.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/scroller/js/scroller-custom.js"></script> 
<script src="files/assets/pages/data-table/extensions/select/js/dataTables.select.min.js"></script> 
<script src="files/assets/pages/data-table/extensions/select/js/select-custom.js"></script> 
<script type="a24b6c627f2b43fcb6f7975d-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>
</body>
</html>
