<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday"/>
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">

<script src="http://code.jquery.com/jquery-latest.min.js"></script>

	
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>  

    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
       
      
<?php 
          include 'sidebar.php'; 
      ?>
      
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-8">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-1.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Tour Packages</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Tour Packages</a></li>
                    <li class="breadcrumb-item"><a href="#"> Add Tour Packages </a></li>
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                	<div class="page-body">
                		<div class="form-group admin-form">
					
              <form method="post" action="add_tourpackages_insert.php" enctype="multipart/form-data" id="form1">
								
                            	<div class="row">
<?php			 
$packageplaceid="";
$tour_packages_id="";
$packagename="";
$packageprice="";
$agentprice="";
$childprice ="";
$agentchildprice="";
$days="";
$packageimg="";
$packagedescription="";
$daytitle="";
$daytitledetail="";

$inclusion="";
$exclusion="";
$note="";
$cancelpolicy="";
$hotdeals="";
$tour_packages_date="";
$status="";

if(isset($_REQUEST['btnsubmit']))

 {
	
		$cnt = fetchsinglecol($conn,"select count(*) from  tour_packages where tour_packages_id = '".$_REQUEST['txttpid']."' &&  package_name='".$_REQUEST['txtpackagename']."' ");
		if($cnt == "0")
		{
				move_uploaded_file($_FILES['txtfile']['tmp_name'], "images/packages/".date('Ymd').$_FILES['txtfile']['name']);
				$file = date('Ymd').$_FILES['txtfile']['name'];
							
							
			
			cuddata($conn,"insert into tour_packages (package_name,package_price,agent_price,days,tour_packages_img,package_description,day_title_id,inclusion,exclusion,note,cancel_policy,hot_deals,tour_packages_date,status) values ('".$_REQUEST['txtpackagename']."','".$_REQUEST['txtpackageprice']."','".$_REQUEST['txtagentprice']."','".$_REQUEST['txtdays']."','".$file."','".$_REQUEST['txtpackagedescription ']."','".$_REQUEST['txtinclusion']."','".$_REQUEST['txtexclusion']."','".$_REQUEST['txtnote']."','".$_REQUEST['txtcancelpolicy']."','".$_REQUEST['txthotdeals']."','".$_REQUEST['txttourpackagesdate']."','Y')");
		
		?>
			<div class="alert alert-success alert-dismissable">
            									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              									<center><?php echo "Successfully Tour Packages Added...!" ?> </center></div>
												
			<?php	
		}
		else
		{
			cuddata($conn,"update tour_packages set package_name='".$_REQUEST['txtpackagename']."',package_price='".$_REQUEST['txtpackageprice']."',agent_price='".$_REQUEST['txtagentprice']."',days='".$_REQUEST['txtdays']."',tour_packages_img='".$file."',package_description='".$_REQUEST['txtpackagedescription']."',day_title_id='".$_REQUEST['txtdtid']."',inclusion='".$_REQUEST['txtinclusion']."',exclusion='".$_REQUEST['txtexclusion']."',note='".$_REQUEST['txtnote']."',cancel_policy='".$_REQUEST['txtcancelpolicy']."',hot_deals='".$_REQUEST['txthotdeals']."' where tour_packages_id = '".$_REQUEST['txtpid']."'");
			
			?>
			<div class="alert alert-success alert-dismissable">
            									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              									<center><?php echo "Successfully Update Tour Packages..!" ?> </center></div>
												
			<?php
		}
	
}
	?>
    
    <div class="col-md-6">
                                        <label> Package Place</label>
                                      
                                        <select class="form-control" id="select_package_place"   placeholder="Select Package Place" name="txtppid" required>
                                            <option value="">Select Package Place</option>
                                            <?php
                                                    $resultjt=mysqli_query($conn,"select * from package_place");
                                                while($rowjt=mysqli_fetch_array($resultjt))
                                                {
                                                ?>	
                                                <option value="<?php echo $rowjt["package_place_id"]; ?>"><?php echo $rowjt["package_place_title"]; ?></option>
                                            <?php } ?>
                                            
                                        </select>

                                        
                                        <span class="field-validation-valid text-danger" data-valmsg-for="FromPoint" data-valmsg-replace="true"></span>
                                    </div>

                                    <div class="col-md-6">
                                        <label> Package </label>
                                        <input data-val="true" data-val-number="The field PkgId must be a number." data-val-required="The PkgId field is required." id="PkgId" name="PkgId" type="hidden" value="">
                                  
                                        <input type="text" id="package_name" name="txtpackagename" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $packagename; ?>" placeholder="Package Name" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Package Name"  >
                                       
                                        <span class="field-validation-valid text-danger" data-valmsg-for="PackageName" data-valmsg-replace="true"></span>
                                    </div>
                
                                    
                				</div>

                        <div class="row">
              
                
                                    <div class="col-md-6">
                                        <label> Adult  Price ฿ </label>
                                        <input type="text" id="package_price" name="txtpackageprice" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $packageprice; ?>" placeholder="Package Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter package price" >
                                        
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Price" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Agent Adult Price ฿ </label>
                                        <input type="text" id="agent_price" name="txtagentprice" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentprice; ?>" placeholder="Agent Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter agent price" >
                                        
                                        <span class="field-validation-valid text-danger" data-valmsg-for="AgentPrice" data-valmsg-replace="true"></span>
                                    </div>
                				</div>
                            <div class="row">
              
                
                                    <div class="col-md-6">
                                        <label> Child  Price ฿ </label>
                                        <input type="text" id="child_price " name="txtchildprice " class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $childprice; ?>" placeholder="Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Child price">
                                        
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Child Price" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Agent Child Price ฿ </label>
                                        <input type="text" id="agent_child_price" name="txtagentchildprice" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentchildprice; ?>" placeholder="Agent Child Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter agent Child price" >
                                        
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Agent Child Price" data-valmsg-replace="true"></span>
                                    </div>
                				</div>
                            	
                            	<div class="row">
                                	<div class="col-md-6">
                                        <label> Days </label>
                                       
                                        <input type="text" id="days" name="txtdays" class="form-control" data-val="true"  value="<?php echo $days; ?>" placeholder="Days" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter days" >
                                       
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Days" data-valmsg-replace="true"></span>
                                    </div>
                                    <div class="col-md-6">
                                        <label> Package Image </label>
                                     <label class="control-label">Product Image</label>
                                 <input type="file" name="txtfile[]" id="txtfile" class="form-control"  multiple="multiple" data-bvalidator="extension[jpg:png:JPG],required" required="required"  data-bvalidator-msg="Please select file of type .jpg, .png, .JPG" >
                         
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Image" data-valmsg-replace="true"></span>
                                    </div>
                            	</div>
                                
                                <div class="row">
                                	<div class="col-md-12">
                                        <label> Description </label>
                                        <textarea class="form-control" cols="20" id="package_description" name="txtpackagedescription" placeholder="Package Overview" required rows="4" value="<?php echo $packagedescription; ?>"></textarea>
                                      
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Description" data-valmsg-replace="true"></span>
                                    </div>
                                </div>
                              
                                <div id="multiple_fields">
                                <div class="row">
                                        <div class="col-md-4">
                                            <label> Day Title (Itinerary) </label>
                                            <input class="form-control" id="titles" name="txttitles[]" placeholder="Title" required="required" type="text" value="<?php echo $daytitle; ?>">
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Daytitle" data-valmsg-replace="true"></span>
                                            
                                        </div>
                                        <div class="col-md-8">
                                            <label> Details </label>
                                            <textarea class="form-control" cols="20" id="day_details" name="txtdaydetails[]" placeholder="Day Details" required rows="4" value="<?php echo $daytitledetail; ?>"></textarea>
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span>
                                        </div>
                                </div>
                                
                                </div>
                                <div class="addday-btn">
                                                <button class="extra-fields-customer" id="add_more">+ Add More Day </button>
				 
                                </div>
                                <br/> <br/>
                            	<div class="row">
                               
                                    <div class="col-md-6">
                                        <label> Inclusion </label>
                                        <textarea class="form-control" cols="20" id="inclusion" name="txtinclusion" placeholder="Inclution" required rows="4" value="<?php echo $inclusion; ?>"></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Inclusion" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Exclusion </label>
                                        <textarea class="form-control" cols="20" id="exclusion" name="txtexclusion" placeholder="Exclution" required rows="4" value="<?php echo $exclusion; ?>"></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Exclusion" data-valmsg-replace="true"></span>
                                    </div>
                            	</div>
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <label> Note </label>
                                        <textarea class="form-control" cols="20" id="note" name="txtnote" placeholder="Note" required rows="4" value="<?php echo $note; ?>"></textarea>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Note" data-valmsg-replace="true"></span>
                                    </div>
                
                            
                                </div>
                                
                                <div class="row">
                                	<div class="col-md-4">
                                    	<div class="border-checkbox-group border-checkbox-group-danger">
                                           <input type="hidden" name="chkhotdeals" value="No">
                                        	<input class="border-checkbox" type="checkbox" name ="chkhotdeals"  value="Yes">
                                        	<label class="border-checkbox-label" for="checkbox5" >Display In Hot Deals</label>
										</div>
                                    </div>
                            	</div>
                                
                                <div>
                                <input type="hidden" value="<?php echo $tour_packages_id; ?>" name="txttourpackagesid" >	
			
                                  

                                    <?php if(isset($_REQUEST['update'])){ ?>
                <button type="submit" class="btn tour-form-btn" name="btnupdate"> Update </button>
                <?php } else { ?>
                <button type="submit" class="btn tour-form-btn" name="btnsubmit">Submit</button>
		      		<?php } ?>
                <input type="button" class="btn " style="margin-bottom: 0px;" value="Cancel" onClick="location='tourpackages.php'" />
                                </div>
							</form>   
     					</div>
                	</div>
              	</div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>





<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/add.js"></script>

<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>



<script type="text/javascript">

  jQuery(document).ready(function($){
	
	  //$('#add_more').click(function(event){
	  $('#add_more').on('click', function(event)
    {
		  
		  event.preventDefault();
		   var count=$('#multiple_fields').children().length;
	       var txtHint4=$('#multiple_fields').append('<div class="row"><div class="col-md-4"><label> Day Title (Itinerary) </label><input class="form-control" id="titles" name="txttitles[]" placeholder="Title" required="required" type="text" value="<?php echo $daytitle; ?>"><span class="field-validation-valid text-danger" data-valmsg-for="Daytitle" data-valmsg-replace="true"></span><div class="addday-btn"></div></div> <div class="col-md-8"> <label> Details </label><textarea class="form-control" cols="20" id="day_details" name="txtdaydetails[]" placeholder="Day Details" required rows="4" value="<?php echo $daytitledetail; ?>"></textarea><span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span></div></div>');
		  
      
	  });


	  
  });
</script>


</body>
</html>
