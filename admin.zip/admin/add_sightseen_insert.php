<?php

include 'connection.php';

$data = $_POST;

$count = count($_FILES["txtfile"]["name"]);

$cnt = fetchsinglecol($conn, "select max(sightseen_id) from  sightseen");
$pid = $cnt + 1;

foreach ($_FILES["txtfile"]["name"] as $i => $value) 
{
	
    move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/sightseen/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
    $file = date('Ymd') . $_FILES['txtfile']['name'][$i];

    $sightseendate=date("Y-m-d H:i:s");
 
    $sql = "INSERT INTO `sightseen`(`sightseen_id`, `sightseen_title`, `sight_seen_place_id`, `sightseen_details`, `sightseen_package_image`, `sightseen_date`, `status`) VALUES('" . $pid . "','".$_REQUEST['txtsightseentitle']."','".$_REQUEST['txtssid']."','".$_REQUEST['txtsightseendetails']."','".$file."','".$sightseendate."','Y')";
    //echo $sql;
    //die();
    mysqli_query($conn, $sql);
}

function fetchsinglecol($conn, $query)
{
    $Q = mysqli_query($conn, $query) or die(mysqli_error());
    $data = mysqli_fetch_array($Q);
    return $data[0];

}

if (isset($_REQUEST['btnsubmit'])) {
    for ($i = 0; $i < count($_FILES["txtfile"]["name"]); $i++) {
   
        move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/sightseen/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
        $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
    
        $data = mysqli_query($conn, "insert into sightseen_images(sightseen_images_id,sightseen_id,sightseen_package_sub_img) values (null,'" . $pid . "','" . $file . "')") or die(mysqli_error($conn));
        //echo "insert into product_image(product_image_id,product_id,product_sub_img) values (null,'".$cnt."','".$filepath."')";
        //die();
    }

}

echo "<script>window.location='add_sightseen.php';</script>";
exit;