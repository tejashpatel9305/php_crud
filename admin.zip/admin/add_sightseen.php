<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday"/>
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>

    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
        <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-5">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-1.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Tour Guide Master</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-7">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Tour Guide Master</a></li>
                    <li class="breadcrumb-item"><a href="#"> Sight Seen </a></li>
                    <li class="breadcrumb-item"><a href="#"> Add Sight Seen </a></li>
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                	<div class="page-body">
                		<div class="form-group admin-form">
                        <form method="post" action="add_sightseen_insert.php" enctype="multipart/form-data" id="form1">
                        <?php			 
                            $sightseenid="";
                            $sightseentitle="";
                            $sightseenplace="";
                            $sightseendetails="";
                            $sightseenpackageimage="";
                            $sightseendate="";
                            $status="";
                            ?>    
                        
                        
                        <div class="row">
                                    <div class="col-md-6">
                                        <label> Sight Seen </label>
                                        <input data-val="true" data-val-number="The field PkgId must be a number." data-val-required="The PkgId field is required." id="PkgId" name="PkgId" type="hidden" value="">
                                        <input type="text" id="sightseen_title" name="txtsightseentitle" class="form-control" data-val="true"  value="<?php echo $sightseentitle; ?>" placeholder="Sightseen Title" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Sightseen Title" >
                                       
                                        <span class="field-validation-valid text-danger" data-valmsg-for="sightseen" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-6">
                                        <label> Place </label>
                                  
                                      <select class="form-control" id="select_sight_seen_place"   placeholder="Select Sight Seen Place" name="txtssid" required>
                                          <option>Select Sight Seen Place</option>
                                          <?php
                                                  $resultjt=mysqli_query($conn,"select * from sight_seen_place");
                                              while($rowjt=mysqli_fetch_array($resultjt))
                                              {
                                              ?>	
                                              <option value="<?php echo $rowjt["sight_seen_place_id"]; ?>"><?php echo $rowjt["sight_seen_place_title"]; ?></option>
                                          <?php } ?>
                                          
                                      </select>

                                      
                                      <span class="field-validation-valid text-danger" data-valmsg-for="FromPoint" data-valmsg-replace="true"></span>
                       
                                    </div>
                				</div>
                				<div class="row">	
                                    <div class="col-md-6">
                                        <label> Details </label>
                                        <input type="text" id="sightseen_details" name="txtsightseendetails" class="form-control" data-val="true"  value="<?php echo $sightseendetails; ?>" placeholder="Sightseen Details" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Sightseen Details" >                                     
                                       
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Details" data-valmsg-replace="true"></span>
                                    </div>
                                    <div class="col-md-6">
                                        <label> Package Image </label>
                                        <input type="file" name="txtfile[]" class="form-control"  multiple="multiple" data-bvalidator="extension[jpg:png:JPG],required" data-bvalidator-msg="Please select file of type .jpg, .png, .JPG" >
                         
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Image" data-valmsg-replace="true"></span>
                                    </div>
                				</div>
                            	
                               <!-- <div class="row">
                                	<div class="col-md-4">
                                    	<div class="border-checkbox-group border-checkbox-group-danger">
                                        	<input class="border-checkbox" type="checkbox">
                                        	<label class="border-checkbox-label" for="checkbox5">Display In Hot Deals</label>
										</div>
                                    </div>
                            	</div>-->
                              <input type="hidden" value="<?php echo $sightseenid; ?>" name="txtsightseenid" >	
			
                                <div>
                                <?php if(isset($_REQUEST['update'])){ ?>
                                  <button type="submit" class="btn tour-form-btn" name="btnupdate"> Update </button>
                                  <?php } else { ?>
                                  <button type="submit" class="btn tour-form-btn" name="btnsubmit"> Submit </button>
                                  <?php } ?>
                        
                                  <input type="button" class="btn " style="margin-bottom: 0px;" value="Cancel" onClick="location='sightseen.php'" />
                                            
                                </div>
							</form>   
     					</div>
                	</div>
              	</div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>
<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/add.js"></script>

<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>
</body>
</html>
