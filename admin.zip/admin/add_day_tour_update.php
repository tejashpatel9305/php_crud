<?php

include 'connection.php';

$data = $_POST;

$count = count($_FILES["txtfile"]["name"]);

$cnt = fetchsinglecol($conn, "select max(day_tour_id) from day_tour");
$pid = $cnt + 1;

foreach ($_FILES["txtfile"]["name"] as $i => $value) {
	
   // move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/daytour/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
   // $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
   
	$daytourdate=date("Y-m-d H:i:s");
	$checkboxhotdeals=$_POST['chkhotdeals']; 
	$tourdescription = mysqli_real_escape_string($conn,$_REQUEST['txtdescription']);
    $inclusion = mysqli_real_escape_string($conn,$_REQUEST['txtinclusions']);
  	$exclusion = mysqli_real_escape_string($conn,$_REQUEST['txtexclusions']);
	
    $sql = "update day_tour  set   sight_seen_place_id='".$_REQUEST['txtptid']."', sightseen_id='".$_REQUEST['select_title']."', 	 description ='".$tourdescription."', inclusions ='".$inclusion."',exclusions='".$exclusion."',day_title='" . $_REQUEST['txtdaytitle']. "',hot_deals='".$checkboxhotdeals."',day_tour_date='".$daytourdate."', status='Y' where day_tour_id = '".$_REQUEST['update']."'";
   
	//echo $sql;
   // die();
    mysqli_query($conn, $sql);
}

function fetchsinglecol($conn, $query)
{
    $Q = mysqli_query($conn, $query) or die(mysqli_error());
    $data = mysqli_fetch_array($Q);
    return $data[0];

}

/*if (isset($_REQUEST['btnupdate'])) {
    for ($i = 0; $i < count($_REQUEST['txtdurationtitle']); $i++) {
      
      if($_REQUEST['txtdtid'][$i] == ""){
        $data = mysqli_query($conn, "insert into duration_time (duration_time_id,day_tour_id,duration_title,show_time) values (null,'" . $_REQUEST['update'] . "','" . $_REQUEST['txtdurationtitle'][$i]. "','" . $_REQUEST['txtshowtime'][$i] . "')") or die(mysqli_error($conn));
      }else{
        $data = mysqli_query($conn, "update duration_time  set day_tour_id ='".$_REQUEST['update']."', duration_title='" . $_REQUEST['txtdurationtitle'][$i]. "',show_time='" . $_REQUEST['txtshowtime'][$i] . "' where   duration_time_id = '".$_REQUEST['txtdtid']."' ") or die(mysqli_error($conn));   
      }
       
    }

}*/


/*if (isset($_REQUEST['btnupdate'])) {
  for ($i = 0; $i < count($_REQUEST['txtadultprice']); $i++) {
    
    if($_REQUEST['txttourpriceid'][$i] == ""){
      $data = mysqli_query($conn, "insert into tour_price (tour_price_id,day_tour_id,transfer_id,seat_type_id, adult_price,child_price,agent_adult_price, 	agent_child_price) values (null,'" . $_REQUEST['update'] . "','" . $_REQUEST['txttid'][$i]. "','" . $_REQUEST['txtstid'][$i]. "','" . $_REQUEST['txtadultprice'][$i]. "','" . $_REQUEST['txtchildprice'][$i] . "','" . $_REQUEST['txtagentadultprice'][$i]. "','" . $_REQUEST['txtagentchildprice'][$i] . "')") or die(mysqli_error($conn));
    }else{
      $data = mysqli_query($conn, "update tour_price  set day_tour_id ='".$_REQUEST['update']."',transfer_id='" . $_REQUEST['txttid'][$i]. "', seat_type_id='" . $_REQUEST['txtstid'][$i]. "', adult_price='" . $_REQUEST['txtadultprice'][$i]. "', child_price='" . $_REQUEST['txtchildprice'][$i] . "', agent_adult_price='" . $_REQUEST['txtagentadultprice'][$i]. "',agent_child_price='" . $_REQUEST['txtagentchildprice'][$i] . "' where tour_price_id = '".$_REQUEST['txttourpriceid']."' ") or die(mysqli_error($conn));   
    }
     
  }

}*/


if (isset($_REQUEST['btnupdate'])) {
    $$datadurationdelete = mysqli_query($conn, "delete from duration_time  where day_tour_id ='".$_REQUEST['update']."' ");

	for ($i = 0; $i < count($_REQUEST['txtdurationtitle']); $i++) {
  			
      $dataduration = mysqli_query($conn, "insert into duration_time (duration_time_id,day_tour_id,duration_title,show_time) values (null,'" . $_REQUEST['update'] . "','" . $_REQUEST['txtdurationtitle'][$i]. "','" . $_REQUEST['txtshowtime'][$i] . "')") or die(mysqli_error($conn));
		//  echo $dataduration;
		 // die();
      
       
    }

}


if (isset($_REQUEST['btnupdate'])) {
    $tourpricedelete = mysqli_query($conn, "delete from tour_price  where day_tour_id ='".$_REQUEST['update']."' ");

	for ($i = 0; $i < count($_REQUEST['txtadultprice']); $i++) {
      $tourpricedata = mysqli_query($conn, "insert into tour_price (tour_price_id,day_tour_id,transfer_id,seat_type_id, adult_price,child_price,agent_adult_price, 	agent_child_price) values (null,'" . $_REQUEST['update'] . "','" . $_REQUEST['txttid'][$i]. "','" . $_REQUEST['txtstid'][$i]. "','" . $_REQUEST['txtadultprice'][$i]. "','" . $_REQUEST['txtchildprice'][$i] . "','" . $_REQUEST['txtagentadultprice'][$i]. "','" . $_REQUEST['txtagentchildprice'][$i] . "')") or die(mysqli_error($conn));
		//  echo $tourpricedata;
		 // die();
      
       
    }

}

if (isset($_REQUEST['btnupdate']) )
	{
		for ($i = 0; $i < count($_FILES["txtfile"]["name"]); $i++) {
		if (!empty($_FILES['txtfile']['tmp_name'][$i]))
			{
			 move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/daytour/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
        $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
    
        $data = mysqli_query($conn, "insert into day_tour_image(day_tour_image_id,day_tour_id,day_tour_sub_img) values (null,'" . $_REQUEST['update'] . "','" . $file . "')") or die(mysqli_error($conn));
			}
		}

	}
	
    
echo "<script>window.location='daytour.php';</script>";
exit;