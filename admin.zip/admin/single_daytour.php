<?php
session_start();
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}

include 'connection.php';

function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday" />
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="files/assets/css/photo.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">

<link rel="stylesheet" type="text/css" href="files/assets/css/carousel.css">
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>

    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
        	<div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-8">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-1.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Day Tour </h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Tour Guide Master</a></li>
                    <li class="breadcrumb-item"><a href="#"> Day Tour-Details </a></li>
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
              	<section class="section-paddings single-package-area">
	<div class="container">
		<div class="row">
            <!-- single package tab with details -->
<?php	
    if(isset($_REQUEST['view']))
	{ 
		$result=mysqli_query($conn,"select a.*,b.*,c.* from day_tour as a, sight_seen_place as b, tour_price as c where a.sight_seen_place_id=b.sight_seen_place_id and a.day_tour_id=c.day_tour_id  and  a.day_tour_id='".$_REQUEST['view']."' group by a.day_tour_id ");
		while($row=mysqli_fetch_array($result))
		{
            $daytourid=$row["day_tour_id"];
            
            ?>
			<div class="col-md-12 col-sm-12">
				<div class="single-package-details">
					<div class="single-package-title">
						<h2> <?php echo $row['sightseen_title']; ?>  </h2>
					</div>
                    <ul class="package-content">
						<li><?php echo $row['day_title']; ?></li>
						<li>Adult Price : ฿ <?php echo $row['adult_price']; ?> </br> Agent Price : ฿ <?php echo $row['agent_adult_price']; ?> </li>
					</ul>
                    <!--<h4> 6  Nights / 5 Nights </h4>-->
                    
                    
                    <!--<div class="package-tab-menu">
                      	<div class="package-tab-menu">
                          	<div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="">
                                  <li><a href="#description"> Photos </a></li>
                            	  <li><a href="#itinerary"> Itinerary </a></li>
                            	  <li><a href="#video"> Inclusions & Exclusions </a></li>
                                  <li><a href="#map"> Tour Map </a></li>
                            	  <li><a href="#reviews"> Cancellation </a></li>
                                  
                                </ul>
              				</div>
                      	</div>
					</div>-->
                    
                    <div class="scroll-box package-tab-menu">
                        <div class="scroll scroll-fixed" id="scroll">
                          <ul class="package-tab-menu">
                            <li class="active"><a href="#description"> Photos </a></li>
                            <li><a href="#itinerary"> Itinerary </a></li>
                            <li><a href="#video"> Inclusions &amp; Exclusions </a>
                            <!--<li role="presentation"><a href="#map"> Tour Map </a></li></li>-->
                            </li><li><a href="#reviews"> Cancellation </a></li>
                          </ul>
                        </div><!-- tab menu end -->
    
                       
                        

						<!-- Scrollpy content start -->
                
                        <div class="row">
                            <!-- tabs content -->
                            <div class="tab-content">
                                <!-- Photos -->
                                <div id="description">
                                    <div class="row photo-section">
                                        <!-- left content -->
                                        
                                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                          <!-- Indicators -->
                          <ol class="carousel-indicators">
                  <?php        
                        if(isset($_REQUEST['view']))
                            { 
                                $result1=mysqli_query($conn,"select * from day_tour_image where day_tour_id='".$_REQUEST['view']."'");
                                while($row1=mysqli_fetch_array($result1))
                                {
                        ?>
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo $row1['day_tour_image_id']; ?>" class=""></li>
                        
                            <?php } ?>
                        
                            <?php  }
                          ?>
                    
                          <!--  <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                            <li data-target="#carousel-example-generic" data-slide-to="3" class="active"></li>
                            -->
                        </ol>

                          <!-- Wrapper for slides -->
                          <div class="carousel-inner" role="listbox">
                        <?php   $result2=mysqli_query($conn,"select * from day_tour_image where day_tour_id='".$_REQUEST['view']."' limit 1,25");
                                while($row2=mysqli_fetch_array($result2))
                                {
                                ?>


                            <div class="carousel-item">
                              <img src="../images/daytour/<?php echo $row2["day_tour_sub_img"]; ?>" alt="">
                            </div>
                                
                            <?php } ?>
                            <?php   $result3=mysqli_query($conn,"select * from day_tour_image where day_tour_id='".$_REQUEST['view']."' limit 0,1");
                                while($row3=mysqli_fetch_array($result3))
                                {
                                ?>

                            <div class="carousel-item active">
                               <img src="../images/daytour/<?php echo $row3["day_tour_sub_img"]; ?>" alt="">
                            </div>
                            <?php } ?>
                      
                          </div>

                          <!-- Controls -->
                          <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                            <span class="fa fa-angle-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                          </a>
                          <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                            <span class="fa fa-angle-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                          </a>
						</div>
                                        <!-- left-content -->	
                                    </div>
                                </div>
                                <!--END Photos -->
                               
                                <!--Itinerary -->
                                <div class="discription-top" id="itinerary">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="tour-description">
                                                <h4 class="t-box"> Itinerary </h4>
                                                <?php   $result4=mysqli_query($conn,"select * from day_tour where day_tour_id='".$_REQUEST['view']."'");
                                while($row4=mysqli_fetch_array($result4))
                                {
                                ?>

                                                <p><?php echo $row4["description"]; ?></p>
                                                <?php } ?>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--END Itinerary -->
                                <div class="padding-bottom-block" id="video"></div>
                                <!-- Inclusions & Exclusionst -->
                                <div>
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="tour-description">
                                                <h4 class="t-box"> Inclusions </h4>
                                                <!-- Inclusions -->

                                                <ul>
                                                <?php   $result6=mysqli_query($conn,"select * from day_tour where day_tour_id='".$_REQUEST['view']."'");
                                while($row6=mysqli_fetch_array($result6))
                                {
                                    $details=nl2br($row6["inclusions"]);
                                   
                                    $string = str_replace("\n", "<br /><i class='fa fa-check-circle'></i>", $details);
                                    
                                ?>
                               
                                  <li><i class='fa fa-check-circle'></i> <?php echo  $string;  ?> </li>
                                                    
                                                    <?php } ?>
                                                    
                                                </ul>
                                                <!--End Inclusions -->
                                                
                                                <h4 class="t-box"> Exclusions </h4>
                                                <!-- Exclusions -->
                                                <ul>
                                                <?php   $result7=mysqli_query($conn,"select * from day_tour where day_tour_id='".$_REQUEST['view']."'");
                                while($row7=mysqli_fetch_array($result7))
                                {
                                            $details7=nl2br($row7["exclusions"]);
                                        
                                            $string7 = str_replace("\n", "<br /><i class='fa fa-check-circle'></i>", $details7);
                                            
                                        ?>
                                    
                                        <li> <i class='fa fa-check-circle'></i><?php echo  $string7;  ?> </li>
                                  <?php } ?>
                                                  
                                                </ul>
                                                <!--End Exclusions -->
                                                
                                             
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--END Inclusions & Exclusionst -->
                                
                                <!-- MAP -->
                                <!--<div id="map">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="tour-description">
                                                <h4 class="t-box1">Map Tour</h4>
                                                <!-- map --
                                                <div class="mapp" id="overlay">
                                                    <iframe id="maping" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3350.701132954845!2d-96.89708368545975!3d32.879626086054884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864e9d666937c1f7%3A0xae26e896218f405!2sUSA+Bowl!5e0!3m2!1sbn!2sbd!4v1493296407400" allowfullscreen></iframe>
                                                </div><!-- map --
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                                <!--END MAP -->
        
                                <!-- Cancellation -->
                                <div id="reviews">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="tour-description">
                                                <h4 class="t-box"> Cancellation Charges </h4>
                                                <table class="table table-bordered customize-table-style1">
                                                    <thead>
                                                        <tr class="tbl-head">
                                                            <th>No of days prior to departure</th>
                                                            <th>Charges</th>
                                                            <th>Applied On</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                                    <tr>
                                                                        <td data-title="No. days prior to dep">0-7 Days</td>
                                                                            <td data-title="Charges">
                                                                                100 <b> % </b>
                                                                            </td>
                                                                        <td data-title="Applied On">Package price per person</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td data-title="No. days prior to dep">8-14 Days</td>
                                                                            <td data-title="Charges">
                                                                                75 <b> % </b>
                                                                            </td>
                                                                        <td data-title="Applied On">Package price per person</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td data-title="No. days prior to dep">15-29 Days</td>
                                                                            <td data-title="Charges">
                                                                                50 <b> % </b>
                                                                            </td>
                                                                        <td data-title="Applied On">Package price per person</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td data-title="No. days prior to dep">30-45 Days</td>
                                                                            <td data-title="Charges">
                                                                                25 <b> % </b>
                                                                            </td>
                                                                        <td data-title="Applied On">Package price per person</td>
                                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--End Cancellation -->
                            </div>
                            <!-- tabs content-->
                        </div>
                		<!--END Scrollpy content -->
                    
                 	</div>   
			 	</div><!-- tab menu strat -->

            </div><!-- single package tab with details -->
            
      <?php  }
	}?>
	
		</div>
	</div>
</section>
              </div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>
<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>
</body>
</html>
