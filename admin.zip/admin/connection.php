<?php
$conn = mysqli_connect("localhost","root","","ariesholiday") or die(mysqli_error("connection not found"));

?>