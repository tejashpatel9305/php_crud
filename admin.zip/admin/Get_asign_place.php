<?php

include 'connection.php';
$q=$_REQUEST["q"];

$sem_sql="SELECT * FROM sightseen WHERE sight_seen_place_id ='$q'";
$sem_result = mysqli_query($conn,$sem_sql);
$sem_html = "<select name='select_title' class='form-control' id='select_title'>";
$sem_html .= "<option value=''>select</option>";
while($sem_row = mysqli_fetch_array($sem_result))
{
	$id=$sem_row['sightseen_id'];
	$sem_html .= "<option value='$id'>" . $sem_row['sightseen_title'] . "</option>";
}
$sem_html .= "</select>";
$resp['sem'] = $sem_html;


echo json_encode($resp);

exit;
 
mysqli_close($conn);
?>