<?php

include 'connection.php';

$data = $_POST;

$count = count($_FILES["txtfile"]["name"]);

$cnt = fetchsinglecol($conn, "select max(day_tour_id) from  day_tour");
$pid = $cnt + 1;

foreach ($_FILES["txtfile"]["name"] as $i => $value) 
{
	
    move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/daytour/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
    $file = date('Ymd') . $_FILES['txtfile']['name'][$i];

    $daytourdate=date("Y-m-d H:i:s");
	$checkboxhotdeals=$_POST['chkhotdeals']; 
	$description = mysqli_real_escape_string($conn,$_POST['txtdescription']);
    $inclusion = mysqli_real_escape_string($conn,$_POST['txtinclusions']);
	$exclusion = mysqli_real_escape_string($conn,$_POST['txtexclusions']);
 
    $sql = "INSERT INTO `day_tour`(`day_tour_id`, `sight_seen_place_id`,`sightseen_id`, `description`, `inclusions`, `exclusions`, `day_title`, `day_tour_img`, `hot_deals`, `day_tour_date`, `status`) VALUES('" . $pid . "','".$_REQUEST['txtptid']."','".$_REQUEST['select_title']."','".$description."','".$inclusion."','".$exclusion."','".$_REQUEST['txtdaytitle']."','".$file."','".$checkboxhotdeals."','".$daytourdate."','Y')";
    //echo $sql;
   // die();
    mysqli_query($conn, $sql);
}	

function fetchsinglecol($conn, $query)
{
    $Q = mysqli_query($conn, $query) or die(mysqli_error());
    $data = mysqli_fetch_array($Q);
    return $data[0];

}

if (isset($_REQUEST['btnsubmit'])) {
    for ($i = 0; $i < count($_REQUEST['txtdurationtitle']); $i++) {
      
        $data = mysqli_query($conn, "insert into duration_time (duration_time_id,day_tour_id,duration_title,show_time) values (null,'" . $pid . "','" . $_REQUEST['txtdurationtitle'][$i] . "','" . $_REQUEST['txtshowtime'][$i] . "')") or die(mysqli_error($conn));
       
    }

}

if (isset($_REQUEST['btnsubmit'])) {
    for ($i = 0; $i < count($_REQUEST['txtadultprice']); $i++) {
      
        $data = mysqli_query($conn, "insert into tour_price (tour_price_id,day_tour_id,transfer_id,seat_type_id,adult_price,child_price,agent_adult_price,agent_child_price) values (null,'" . $pid . "','" . $_REQUEST['txttid'][$i]. "','" . $_REQUEST['txtstid'][$i]. "','" . $_REQUEST['txtadultprice'][$i]. "','" . $_REQUEST['txtchildprice'][$i] . "','" . $_REQUEST['txtagentadultprice'][$i] . "','" . $_REQUEST['txtagentchildprice'][$i] . "')") or die(mysqli_error($conn));
       
    }

}

if (isset($_REQUEST['btnsubmit'])) {
    for ($i = 0; $i < count($_FILES["txtfile"]["name"]); $i++) {
   
        move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/daytour/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
        $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
    
        $data = mysqli_query($conn, "insert into day_tour_image(day_tour_image_id,day_tour_id,day_tour_sub_img) values (null,'" . $pid . "','" . $file . "')") or die(mysqli_error($conn));
        //echo "insert into product_image(product_image_id,product_id,product_sub_img) values (null,'".$cnt."','".$filepath."')";
        //die();
    }

}

echo "<script>window.location='daytour.php';</script>";
exit;