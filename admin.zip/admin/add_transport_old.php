<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday"/>
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script>
$(document).ready(function(){
    $('#select_Transfer').on('change', function() {
      if ( this.value == '5')
      //.....................^.......
      {
        $("#privatedata").hide();
        $("#sicdata").show();
      }
      else  if ( this.value == '4')
      {
          $("#sicdata").hide();
        $("#privatedata").show();
      }
       else  
      {
        $("#sicdata").hide();
      }
    });
});
</script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>
    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-5">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-4.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Transport Master</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-7">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Transport Master</a></li>
                    <li class="breadcrumb-item"><a href="#"> Transport </a></li>
                    <li class="breadcrumb-item"><a href="#"> Add Transport </a></li>
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                	<div class="page-body">
                		<div class="form-group admin-form">
							<form method="post" action="add_transport_insert.php" enctype="multipart/form-data" id="form1">
              <?php			 
                  $transportid="";
                  $journeytypeid="";
                  
                  $frommasterid="";
                  $tomasterid="";
                  $enroutid="";
                  $vehicleid="";
                  $transportrate="";
                  $transportagentrate="";

                  $adultrate="";
                  $agentadultrate="";
                  $childrate="";
                  $agentchildrate="";

                  $transportimg="";
                  $transportdate="";
                  $status="";
                ?>
                            	<div class="row">
                            
                                    <div class="col-md-4">
                                        <label> From </label>
                                        <input data-val="true" data-val-number="The field PkgId must be a number." data-val-required="The PkgId field is required." id="PkgId" name="PkgId" type="hidden" value="">
                                       
                                        <select class="form-control" id="select_from"   placeholder="Select From" name="txtfid" required>
                                            <option value="">Select From</option>
                                            <?php
                                                    $result2=mysqli_query($conn,"select * from from_master order by from_name ASC");
                                                while($row2=mysqli_fetch_array($result2))
                                                {
                                                ?>	
                                                <option value="<?php echo $row2["from_master_id"]; ?>"><?php echo $row2["from_name"]; ?></option>
                                            <?php } ?>
                                            
                                        </select>

                                        <!--<select class="form-control" data-val="true" data-val-number="The field FromPoint must be a number." id="FromPoint" name="FromPoint" required><option value="">--select From--</option>
                                            <option value="1">None</option>
                                            <option value="2">Suvarnabhumi Airport</option>
                                            <option value="3">Pattaya</option>
                                            <option value="4">U Tapao  Airport</option>
                                            <option value="5">Bangkok ,Pratunam /Sukhumvit</option>
                                            <option value="6">Bangkok,Sukhumvit</option>
                                            <option value="11">DMK Airport</option>
                                            <option value="12">Phuket Airport</option>
                                            <option value="13">Phuket,Patong,Katu,</option>
                                            <option value="14">Krabi,Aonang</option>
                                            <option value="15">Krabi Airport</option>
                                            <option value="16">Donsak Pier</option>
                                            <option value="17">Suratthani Airport</option>
                                            <option value="18">Koh Samui Airport</option>
                                            <option value="19">Koh Samui Hotel</option>
                                            <option value="20">Rassada pier</option>
									                  	</select>-->
                                        <span class="field-validation-valid text-danger" data-valmsg-for="FromPoint" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-4">
                                        <label> To </label>
                                       
                                        <select class="form-control" id="select_to"   placeholder="Select To" name="txttid" required>
                                            <option value="">Select To</option>
                                            <?php
                                                $result3=mysqli_query($conn,"select * from to_master order by to_name ASC");
                                                while($row3=mysqli_fetch_array($result3))
                                                {
                                                ?>	
                                                <option value="<?php echo $row3["to_master_id"]; ?>"><?php echo $row3["to_name"]; ?></option>
                                            <?php } ?>
                                            
                                        </select>
                                       <!-- <select class="form-control" data-val="true" data-val-number="The field ToPoint must be a number." id="ToPoint" name="ToPoint" required><option value="">--select To--</option>
                                            <option value="1">None</option>
                                            <option value="2"> 	Suvarnabhumi Airport</option>
                                            <option value="3">Pattaya</option>
                                            <option value="4">U Tapao Airport</option>
                                            <option value="5">Bangkok ,Pratunam/ Sukhumvit</option>
                                            <option value="7">DMK Airport</option>
                                            <option value="8"> 	Phuket,Patong,Katu,</option>
                                            <option value="9">Phuket Airport</option>
                                            <option value="10">Krabi,Aonang</option>
                                            <option value="11">Krabi,Airport</option>
                                            <option value="12">Donsak Pier</option>
                                            <option value="13">Suratthani Airport</option>
                                            <option value="14">Koh Samui Airport</option>
                                            <option value="15">Koh Samui Hotel</option>
                                            <option value="16">Rassada pier</option>
									                    	</select>-->
                                        <span class="field-validation-valid text-danger" data-valmsg-for="ToPoint" data-valmsg-replace="true"></span>
                                    </div>
                                    </div>
                              <div class="row">
                                 <div class="table-responsive">
                                  <table class="table table-bordered" id="dynamic_field">
                                  <tr>
                                      <td>
                                            <div class="col-md-12">
                                              <label> Journey Type</label>
                                            
                                              <select class="form-control" id="select_journey_type"   placeholder="Select Journey Type" name="txtjtid" required>
                                                  <option value="">Select Journey Type</option>
                                                  <?php
                                                          $resultjt=mysqli_query($conn,"select * from journey_type");
                                                      while($rowjt=mysqli_fetch_array($resultjt))
                                                      {
                                                      ?>	
                                                      <option value="<?php echo $rowjt["journey_type_id"]; ?>"><?php echo $rowjt["journey_type_name"]; ?></option>
                                                  <?php } ?>
                                                  
                                              </select>

                                          
                                              <span class="field-validation-valid text-danger" data-valmsg-for="FromPoint" data-valmsg-replace="true"></span>
                                           </div>

                                      </td>


                                      <td>
                                      
                                              <div class="col-md-12">
                                                <label> Enrout </label>
                                                <select class="form-control" id="select_enrout"   placeholder="Select Enrout" name="txteid" required>
                                                    <option value="">Select Enrout</option>
                                                    <?php
                                                        $result4=mysqli_query($conn,"select * from enrout");
                                                        while($row4=mysqli_fetch_array($result4))
                                                        {
                                                        ?>	
                                                        <option value="<?php echo $row4["enrout_id"]; ?>"><?php echo $row4["enrout_name"]; ?></option>
                                                    <?php } ?>
                                                    
                                                </select>
                                            
                                                <span class="text-danger field-validation-valid" data-valmsg-for="InBetween" data-valmsg-replace="true"></span>
                                            </div>
                              
                                      </td>
                                      <td>

                                            <div class="col-md-12">
                                              <label> Vehicle </label>
                                              <select class="form-control" id="select_vehicle"   placeholder="Select Vehicle" name="txtvid" required>
                                                  <option value="">Select Vehicle</option>
                                                  <?php
                                                      $result5=mysqli_query($conn,"select * from vehicle");
                                                      while($row5=mysqli_fetch_array($result5))
                                                      {
                                                      ?>	
                                                      <option value="<?php echo $row5["vehicle_id"]; ?>"><?php echo $row5["vehicle_name"]; ?></option>
                                                  <?php } ?>
                                                  
                                              </select>
                                              
                                              <span class="field-validation-valid text-danger" data-valmsg-for="Vehical" data-valmsg-replace="true"></span>
                                          </div>
                                      </td>
                                    
                                      <td>

                                      <div class="col-md-12">
                                        <label> Transfer </label>
                                        <select class="form-control" id="select_Transfer"   placeholder="Select Transfer" name="txtpid"  required>
                                            <option value="">Select Transfer</option>
                                            <?php
                                                $result6=mysqli_query($conn,"select * from transfer where transfer_id = '4' or transfer_id = '5'");
                                                while($row6=mysqli_fetch_array($result6))
                                                {
                                                   $tansid=$row6["transfer_id"];
                                                ?>	
                                                <option value="<?php echo $row6["transfer_id"]; ?>"><?php echo $row6["transfer_title"]; ?></option>
                                            <?php } ?>
                                            
                                        </select>
                                      

                                        <span class="field-validation-valid text-danger" data-valmsg-for="Vehical" data-valmsg-replace="true"></span>
                                      </div>

                                      </td>
                                     <td>
                                        <div class="col-md-2">
                                          <div class="addday-btn-two">
                                            <a href="#" class="extra-fields-customer" id="add" name="add"> + Add More </a>
                                          </div>
                                        </div>
                                     </td>
                                  </tr>
                                  
                                  
                                  </table>
                                  
                                 </div>
                              </div>
                                   
                                  
                                    <div class="row" id="sicdata" style='display:none;'>	
                                        <div class="col-md-4">
                                            <label> Rate in ฿ </label>
                                            <input type="text" id="transport_rate" name="txttransportrate" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $transportrate; ?>" placeholder="Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Rate Price" >                                         
                                    
                                            <span class="field-validation-valid text-danger" data-valmsg-for="Rate" data-valmsg-replace="true"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <label> Agent Rate in ฿ </label>
                                            <input type="text" id="transport_agent_rate" name="txttransportagentrate" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $transportagentrate; ?>" placeholder="Agent Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Rate Price" >                                         
                                            <span class="field-validation-valid text-danger" data-valmsg-for="AgentRate" data-valmsg-replace="true"></span>
                                        </div>
                                    </div>
                                    <div>
                                            <div class="row" id="privatedata" style='display:none;'>	
                                                <div class="col-md-2">
                                                    <label> Adult Rate in ฿ </label>
                                                    <input type="text" id="adult_rate" name="txtadultrate[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $adultrate; ?>" placeholder="Adult Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Adult Rate Price" >                                         
                                            
                                                    <span class="field-validation-valid text-danger" data-valmsg-for="Rate" data-valmsg-replace="true"></span>
                                                </div>
                                                <div class="col-md-2">
                                                    <label> Agent Adult Rate in ฿ </label>
                                                    <input type="text" id="agent_adult_rate" name="txtagentadultrate[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentadultrate; ?>" placeholder="Agent Adult Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Adult Rate Price" >                                         
                                                    <span class="field-validation-valid text-danger" data-valmsg-for="AgentRate" data-valmsg-replace="true"></span>
                                                </div>
                                                <div class="col-md-2">
                                                    <label> Child Rate in ฿ </label>
                                                    <input type="text" id="child_rate" name="txtchildrate[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $childrate; ?>" placeholder="Child Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Child Rate Price" >                                         
                                            
                                                    <span class="field-validation-valid text-danger" data-valmsg-for="Rate" data-valmsg-replace="true"></span>
                                                </div>
                                                <div class="col-md-3">
                                                    <label> Agent Child Rate in ฿ </label>
                                                    <input type="text" id="agent_child_rate" name="txtagentchildrate[]" style="width:77%;" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentchildrate; ?>" placeholder="Agent Child Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Child Rate Price" >                                         
                                                    <span class="field-validation-valid text-danger" data-valmsg-for="AgentRate" data-valmsg-replace="true"></span>
                                                </div>
                                            
                                    </div>
              
                            </div>
                                  
                                  
                                      <div class="row">	
                                                  <div class="col-md-12">
                                                      <label> Image </label>
                                                      <input type="file" name="txtfile[]" class="form-control"  multiple="multiple" data-bvalidator="extension[jpg:png:JPG],required" required="required"  data-bvalidator-msg="Please select file of type .jpg, .png, .JPG" >
                                                          
                                                      <span class="field-validation-valid text-danger" data-valmsg-for="Image" data-valmsg-replace="true"></span>
                                                  </div>
                                      </div>
                                 
                				
                               <!-- <div class="row">
                                	<div class="col-md-4">
                                    	<div class="border-checkbox-group border-checkbox-group-danger">
                                        	<input class="border-checkbox" type="checkbox">
                                        	<label class="border-checkbox-label" for="checkbox5">Display In Hot Deals</label>
										</div>
                                    </div>
                            	</div>-->
                              <input type="hidden" value="<?php echo $transportid; ?>" name="txttransportid" >	
			
                                
                                <div>
                                <?php if(isset($_REQUEST['update'])){ ?>
                                    <button type="submit" class="btn tour-form-btn" name="btnupdate"> Update </button>
                                    <?php } else { ?>
                                    <button type="submit" class="btn tour-form-btn" name="btnsubmit">Submit</button>
                                  <?php } ?>
                                    <input type="button" class="btn " style="margin-bottom: 0px;" value="Cancel" onClick="location='transport.php'" />
                                                  
                                </div>
							</form>   
     					</div>
                	</div>
              	</div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>



<script>
      $(document).ready(function(){
        var i=1;
        $('#add').click(function(){
        i++;
        $('#dynamic_field').append('<tr id="row'+i+'"><td><div class="col-md-12"><label> Journey Type</label> <select class="form-control" id="select_journey_type"   placeholder="Select Journey Type" name="txtjtid" required><option value="">Select Journey Type</option> <?php $resultjt=mysqli_query($conn,"select * from journey_type"); while($rowjt=mysqli_fetch_array($resultjt)) { ?>	<option value="<?php echo $rowjt["journey_type_id"]; ?>"><?php echo $rowjt["journey_type_name"]; ?></option><?php } ?> </select> <span class="field-validation-valid text-danger" data-valmsg-for="FromPoint" data-valmsg-replace="true"></span></div> </td><td><div class="col-md-12"><label> Enrout </label> <select class="form-control" id="select_enrout"   placeholder="Select Enrout" name="txteid" required> <option value="">Select Enrout</option> <?php  $result4=mysqli_query($conn,"select * from enrout"); while($row4=mysqli_fetch_array($result4)) { ?>	 <option value="<?php echo $row4["enrout_id"]; ?>"><?php echo $row4["enrout_name"]; ?></option><?php } ?></select><span class="text-danger field-validation-valid" data-valmsg-for="InBetween" data-valmsg-replace="true"></span></div></td><td><div class="col-md-12"><label> Vehicle </label><select class="form-control" id="select_vehicle"   placeholder="Select Vehicle" name="txtvid" required><option value="">Select Vehicle</option> <?php $result5=mysqli_query($conn,"select * from vehicle");while($row5=mysqli_fetch_array($result5)){?><option value="<?php echo $row5["vehicle_id"]; ?>"><?php echo $row5["vehicle_name"]; ?></option><?php } ?> </select><span class="field-validation-valid text-danger" data-valmsg-for="Vehical" data-valmsg-replace="true"></span></div></td><td><div class="col-md-12"> <label> Transfer </label> <select class="form-control" id="select_Transfer"   placeholder="Select Transfer" name="txtpid"  required> <option value="">Select Transfer</option> <?php $result6=mysqli_query($conn,"select * from transfer where transfer_id = '4' or transfer_id = '5'"); while($row6=mysqli_fetch_array($result6)) { $tansid=$row6["transfer_id"]; ?>	<option value="<?php echo $row6["transfer_id"]; ?>"><?php echo $row6["transfer_title"]; ?></option><?php } ?></select><span class="field-validation-valid text-danger" data-valmsg-for="Vehical" data-valmsg-replace="true"></span></div></td><td> <div class="col-md-2"><br/><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">Remove</button></div></td></tr>');
        });
        
      $(document).on('click', '.btn_remove', function(){
      var button_id = $(this).attr("id"); 
      $('#row'+button_id+'').remove();
        });
      });
</script>


<script type="text/javascript">
  jQuery(document).ready(function($)
  {
	  //$('#add_more').click(function(event){
	  $('#add_more_price').on('click', function(event)
    {	  
		   event.preventDefault();
		   var count=$('#multiple_fields_price').children().length;
	     var txtHint4=$('#multiple_fields_price').append('<div class="row" id="privatedata" style='display:none;'><div class="col-md-2"><label> Adult Rate in ฿ </label><input type="text" id="adult_rate" name="txtadultrate[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $adultrate; ?>" placeholder="Adult Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Adult Rate Price" > <span class="field-validation-valid text-danger" data-valmsg-for="Rate" data-valmsg-replace="true"></span></div><div class="col-md-2"> <label> Agent Adult Rate in ฿ </label><input type="text" id="agent_adult_rate" name="txtagentadultrate[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentadultrate; ?>" placeholder="Agent Adult Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Adult Rate Price" ><span class="field-validation-valid text-danger" data-valmsg-for="AgentRate" data-valmsg-replace="true"></span></div> <div class="col-md-2"><label> Child Rate in ฿ </label> <input type="text" id="child_rate" name="txtchildrate[]" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $childrate; ?>" placeholder="Child Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Child Rate Price" > <span class="field-validation-valid text-danger" data-valmsg-for="Rate" data-valmsg-replace="true"></span></div><div class="col-md-3"><label> Agent Child Rate in ฿ </label><input type="text" id="agent_child_rate" name="txtagentchildrate[]" style="width:77%;" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $agentchildrate; ?>" placeholder="Agent Child Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Child Rate Price" ><span class="field-validation-valid text-danger" data-valmsg-for="AgentRate" data-valmsg-replace="true"></span></div><div class="col-md-2"><div class="addday-btn-two"><a href="#" class="extra-fields-customer" id="add_more_price"> + Add New </a></div></div></div>')
    });
  });
</script>


  

<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/add.js"></script>

<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>

</body>
</html>
