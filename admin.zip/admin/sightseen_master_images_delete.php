<?php

include 'connection.php';

if (isset($_REQUEST['delete']))
{
 $deleteresult=mysqli_query($conn,"SELECT * FROM sightseen_images where sightseen_images_id = '".$_REQUEST['delete']."'");
   while($deleterow=mysqli_fetch_array($deleteresult))
   {
		$sightseenimagesid = $deleterow["sightseen_images_id"];
		$sightseenid = $deleterow["sightseen_id"];

   }
   unlink("../images/sightseen/".$_REQUEST['img']);
   mysqli_query($conn,"delete from sightseen_images where sightseen_images_id ='".$_REQUEST['delete']."'");

}
  
header('Location: edit_sightseen.php?update='.$sightseenid);

	exit;
?>