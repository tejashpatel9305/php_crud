<?php
session_start();
if(isset($_SESSION['adminame']))
{
	unset($_SESSION['adminame']);
	echo "<script>window.location='index.php';</script>";
}
?>