<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday"/>
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
<script src="http://code.jquery.com/jquery-latest.min.js"></script>


</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>
    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-5">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-4.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Transport Master</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-7">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Transport Master</a></li>
                    <li class="breadcrumb-item"><a href="#"> Transport </a></li>
                    <li class="breadcrumb-item"><a href="#"> Edit Transport </a></li>
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                	<div class="page-body">

                    <?php	if(isset($_REQUEST['update']))
              { 
                $result = mysqli_query($conn,"select * from transport where transport_id='".$_REQUEST['update']."'");
                  
                    while($row = mysqli_fetch_array($result))
                {
                        $transportid = $row["transport_id"];
                        
                }
              }?>
                		<div class="form-group admin-form">
						<form method="post" action="add_transport_update.php?update=<?php echo $transportid ?>"  enctype="multipart/form-data" id="form1">
								
              <?php			 
                  $transportid="";
				          $journeytypeid=""; 
                  $frommasterid="";
                  $tomasterid="";
                  $enroutid="";
                  $vehicleid="";
                  $transportrate="";
                  $transportagentrate="";
                  $transportimg="";
                  $transportdate="";
                  $status="";


                  if(isset($_REQUEST['update']))
                    { 
                        $result=mysqli_query($conn,"select * from transport where transport_id='".$_REQUEST['update']."'");
                        while($row=mysqli_fetch_array($result))
                        {
                    
                            $transportid=$row["transport_id"];
						              	$journeytypeid=$row["journey_type_id"];
                            $frommasterid=$row["from_master_id"];
                            $tomasterid=$row["to_master_id"];
                            $enroutid=$row["enrout_id"];
                            $vehicleid=$row["vehicle_id"];
                            $transportrate=$row["transport_rate"];
                            $transportagentrate=$row["transport_agent_rate"];
                            $transportimg=$row["transport_img"];
                            $transportdate=$row["transport_date"];        
                            $status=$row["status"];

                        }
                    }

                ?>
                            	<div class="row">
									 <div class="col-md-4">
                                        <label> Journey Type </label>
                                        <input data-val="true" data-val-number="The field PkgId must be a number." data-val-required="The PkgId field is required." id="PkgId" name="PkgId" type="hidden" value="">
                                       

                                        <select class="form-control" id="select_journey_type"  placeholder="Select Journey Type" name="txtjtid" >
                                                  <?php
                                              $resultjourneytype=mysqli_query($conn,"select a.*,b.* from  transport as a, journey_type as b  where a.journey_type_id=b.journey_type_id and a.transport_id='".$_REQUEST['update']."'");
                                            while($rowjourneytype=mysqli_fetch_array($resultjourneytype))
                                            {
                                            ?>	
                                                <option value="<?php echo $rowjourneytype["journey_type_id"]; ?>"><?php echo $rowjourneytype["journey_type_name"]; ?></option>
                                                    <?php $editjourneytype= $rowjourneytype["journey_type_id"]; ?>
                                            <?php } ?>

                                            <?php
                                              $resultjourneytype1 =mysqli_query($conn,"select * from journey_type ");
                                            while($rowjourneytype1 =mysqli_fetch_array($resultjourneytype1))
                                            {
                                            ?>	
                                            <option value="<?php echo $rowjourneytype1["journey_type_id"]; ?>"><?php echo $rowjourneytype1["journey_type_name"]; ?></option>
                                                    <?php } ?>
                                        
                  			                  </select>

                                        <!--<select class="form-control" data-val="true" data-val-number="The field FromPoint must be a number." id="FromPoint" name="FromPoint" required><option value="">--select From--</option>
                                            <option value="1">None</option>
                                            <option value="2">Suvarnabhumi Airport</option>
                                            <option value="3">Pattaya</option>
                                            <option value="4">U Tapao  Airport</option>
                                            <option value="5">Bangkok ,Pratunam /Sukhumvit</option>
                                            <option value="6">Bangkok,Sukhumvit</option>
                                            <option value="11">DMK Airport</option>
                                            <option value="12">Phuket Airport</option>
                                            <option value="13">Phuket,Patong,Katu,</option>
                                            <option value="14">Krabi,Aonang</option>
                                            <option value="15">Krabi Airport</option>
                                            <option value="16">Donsak Pier</option>
                                            <option value="17">Suratthani Airport</option>
                                            <option value="18">Koh Samui Airport</option>
                                            <option value="19">Koh Samui Hotel</option>
                                            <option value="20">Rassada pier</option>
									                  	</select>-->
                                        <span class="field-validation-valid text-danger" data-valmsg-for="FromPoint" data-valmsg-replace="true"></span>
                                    </div>
                                    <div class="col-md-4">
                                        <label> From </label>
                                        <input data-val="true" data-val-number="The field PkgId must be a number." data-val-required="The PkgId field is required." id="PkgId" name="PkgId" type="hidden" value="">
                                       

                                        <select class="form-control" id="select_from"  placeholder="Select From" name="txtfid" >
                                                  <?php
                                              $result1=mysqli_query($conn,"select a.*,b.* from  transport as a, from_master as b  where a.from_master_id=b.from_master_id and a.transport_id='".$_REQUEST['update']."'");
                                            while($row1=mysqli_fetch_array($result1))
                                            {
                                            ?>	
                                                <option value="<?php echo $row1["from_master_id"]; ?>"><?php echo $row1["from_name"]; ?></option>
                                                    <?php $editcat= $row1["from_master_id"]; ?>
                                            <?php } ?>

                                            <?php
                                              $result=mysqli_query($conn,"select * from from_master ");
                                            while($row=mysqli_fetch_array($result))
                                            {
                                            ?>	
                                            <option value="<?php echo $row["from_master_id"]; ?>"><?php echo $row["from_name"]; ?></option>
                                                    <?php } ?>
                                        
                  			                  </select>

                                        <!--<select class="form-control" data-val="true" data-val-number="The field FromPoint must be a number." id="FromPoint" name="FromPoint" required><option value="">--select From--</option>
                                            <option value="1">None</option>
                                            <option value="2">Suvarnabhumi Airport</option>
                                            <option value="3">Pattaya</option>
                                            <option value="4">U Tapao  Airport</option>
                                            <option value="5">Bangkok ,Pratunam /Sukhumvit</option>
                                            <option value="6">Bangkok,Sukhumvit</option>
                                            <option value="11">DMK Airport</option>
                                            <option value="12">Phuket Airport</option>
                                            <option value="13">Phuket,Patong,Katu,</option>
                                            <option value="14">Krabi,Aonang</option>
                                            <option value="15">Krabi Airport</option>
                                            <option value="16">Donsak Pier</option>
                                            <option value="17">Suratthani Airport</option>
                                            <option value="18">Koh Samui Airport</option>
                                            <option value="19">Koh Samui Hotel</option>
                                            <option value="20">Rassada pier</option>
									                  	</select>-->
                                        <span class="field-validation-valid text-danger" data-valmsg-for="FromPoint" data-valmsg-replace="true"></span>
                                    </div>
                	</div>
							<div class="row">
                                    <div class="col-md-4">
                                        <label> To </label>
                                       
                                        

                                        <select class="form-control" id="select_to"  placeholder="Select To" name="txttid" >
                                                  <?php
                                              $result2=mysqli_query($conn,"select a.*,b.* from  transport as a, to_master as b  where a.to_master_id=b.to_master_id and a.transport_id='".$_REQUEST['update']."'");
                                            while($row2=mysqli_fetch_array($result2))
                                            {
                                            ?>	
                                                <option value="<?php echo $row2["to_master_id"]; ?>"><?php echo $row2["to_name"]; ?></option>
                                                    <?php $editcat2= $row2["to_master_id"]; ?>
                                            <?php } ?>

                                            <?php
                                              $result22=mysqli_query($conn,"select * from to_master ");
                                            while($row22=mysqli_fetch_array($result22))
                                            {
                                            ?>	
                                            <option value="<?php echo $row22["to_master_id"]; ?>"><?php echo $row22["to_name"]; ?></option>
                                                    <?php } ?>
                                        
                  			                  </select>

                                       <!-- <select class="form-control" data-val="true" data-val-number="The field ToPoint must be a number." id="ToPoint" name="ToPoint" required><option value="">--select To--</option>
                                            <option value="1">None</option>
                                            <option value="2"> 	Suvarnabhumi Airport</option>
                                            <option value="3">Pattaya</option>
                                            <option value="4">U Tapao Airport</option>
                                            <option value="5">Bangkok ,Pratunam/ Sukhumvit</option>
                                            <option value="7">DMK Airport</option>
                                            <option value="8"> 	Phuket,Patong,Katu,</option>
                                            <option value="9">Phuket Airport</option>
                                            <option value="10">Krabi,Aonang</option>
                                            <option value="11">Krabi,Airport</option>
                                            <option value="12">Donsak Pier</option>
                                            <option value="13">Suratthani Airport</option>
                                            <option value="14">Koh Samui Airport</option>
                                            <option value="15">Koh Samui Hotel</option>
                                            <option value="16">Rassada pier</option>
									                    	</select>-->
                                        <span class="field-validation-valid text-danger" data-valmsg-for="ToPoint" data-valmsg-replace="true"></span>
                                    </div>
                                    <div class="col-md-4">
                                        <label> Enrout </label>


                                        <select class="form-control" id="select_enrout"  placeholder="Select Enrout" name="txteid" >
                                                  <?php
                                              $result3=mysqli_query($conn,"select a.*,b.* from  transport as a, enrout as b  where a.enrout_id=b.enrout_id and a.transport_id='".$_REQUEST['update']."'");
                                            while($row3=mysqli_fetch_array($result3))
                                            {
                                            ?>	
                                                <option value="<?php echo $row3["enrout_id"]; ?>"><?php echo $row3["enrout_name"]; ?></option>
                                                    <?php $editcat3= $row3["enrout_id"]; ?>
                                            <?php } ?>

                                            <?php
                                              $result33=mysqli_query($conn,"select * from enrout ");
                                            while($row33=mysqli_fetch_array($result33))
                                            {
                                            ?>	
                                            <option value="<?php echo $row33["enrout_id"]; ?>"><?php echo $row33["enrout_name"]; ?></option>
                                                    <?php } ?>
                                        
                  			                  </select>

                                       
                                      <!--  <select class="form-control valid" data-val="true" data-val-number="The field InBetween must be a number." id="InBetween" name="InBetween" required><option value="1">None</option>
                                            <option value="2">City Tour Bangkok</option>
                                            <option value="3">Siracha Tiger Zoo</option>
                                            <option value="4">Under Water World</option>
                                            <option value="5">Frost Magical Ice of Siam</option>
                                            <option value="6">Khao Kheow Open Zoo</option>
                                            <option value="7">Noong Nooch Village</option>
                                            <option value="8">Dolphine Show Pattaya</option>
                                            <option value="9">Tiger Park</option>
                                            <option value="10">Safari World</option>
                                            <option value="11">Phuket City Tour</option>
                                            <option value="12">Pattaya City Tour</option>
                                            <option value="13">Hot Spring</option>
									                	</select> -->
                                        <span class="text-danger field-validation-valid" data-valmsg-for="InBetween" data-valmsg-replace="true"></span>
                                    </div>
                			</div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label> Vehicle </label>
                                       
                                       
                                        <select class="form-control" id="select_vehicle"  placeholder="Select Vehicle" name="txtvid" >
                                                  <?php
                                              $result4=mysqli_query($conn,"select a.*,b.* from  transport as a, vehicle as b  where a.vehicle_id=b.vehicle_id and a.transport_id='".$_REQUEST['update']."'");
                                            while($row4=mysqli_fetch_array($result4))
                                            {
                                            ?>	
                                                <option value="<?php echo $row4["vehicle_id"]; ?>"><?php echo $row4["vehicle_name"]; ?></option>
                                                    <?php $editcat4= $row4["vehicle_id"]; ?>
                                            <?php } ?>

                                            <?php
                                              $result44=mysqli_query($conn,"select * from vehicle ");
                                            while($row44=mysqli_fetch_array($result44))
                                            {
                                            ?>	
                                            <option value="<?php echo $row44["vehicle_id"]; ?>"><?php echo $row44["vehicle_name"]; ?></option>
                                                    <?php } ?>
                                        
                  			          </select>

                                      
                                        <!-- <select class="form-control" data-val="true" data-val-number="The field Vehical must be a number." id="Vehical" name="Vehical" required><option value="">--select Vehicle--</option>
                                            <option value="1">Car ( 1-3 person)</option>
                                            <option value="2">Innova / Fortuner (4- 6 person )</option>
                                            <option value="3">Van (4- 7 Person )</option>
									                  	</select>-->

                                        <span class="field-validation-valid text-danger" data-valmsg-for="Vehical" data-valmsg-replace="true"></span>
                                    </div>
                
                                    <div class="col-md-4">
                                        <label> Rate in ฿ </label>
                                        <input type="text" id="transport_rate" name="txttransportrate" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $transportrate; ?>" placeholder="Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Rate Price" >                                         
                                
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Rate" data-valmsg-replace="true"></span>
                                    </div>
								</div>
							  <div class="row">
                                    <div class="col-md-4">
                                        <label> Agent Rate in ฿ </label>
                                        <input type="text" id="transport_agent_rate" name="txttransportagentrate" class="form-control" data-val="true" data-val-number="The field Price must be a number." value="<?php echo $transportagentrate; ?>" placeholder="Agent Rate Price" required="required"  data-bvalidator="required" data-bvalidator-msg="Enter Agent Rate Price" >                                         
                                        <span class="field-validation-valid text-danger" data-valmsg-for="AgentRate" data-valmsg-replace="true"></span>
                                    </div>
                				</div>
                				<div class="row">	
                                    <div class="col-md-12">
                                        <label> Image </label>
                                        <input type="file" name="txtfile[]" class="form-control"  multiple="multiple" data-bvalidator="extension[jpg:png:JPG],required" data-bvalidator-msg="Please select file of type .jpg, .png, .JPG" >
                                            
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Image" data-valmsg-replace="true"></span>
                                    </div>
                				</div>

                                 <label> Multiple Image </label>
                          <div class="row">
                     
                        
                                      
                                    <?php if(isset($_REQUEST['update']))
                                     {      
                                            $Mutliphotoresult=mysqli_query($conn,"SELECT * FROM transport_image WHERE transport_id = '".$_REQUEST['update']."'");
                                            while($photorow=mysqli_fetch_array($Mutliphotoresult))
                                            {
                                              ?>
                                              <div class="col-md-3 col-sm-6">
                                                <div class="single-package">
                                                  <div class="package-image">
                                                                <div class="container">
                                                                  <img src="../images/transport/<?php echo $photorow['transport_sub_image'];?>" alt="Snow" style="width:100%; ">
                                                             <a href="transport_images_delete.php?delete=<?php echo $photorow['transport_image_id']; ?>" data-toggle="tooltip" data-original-title="Delete" class="tabledit-delete-button btn btn-primary waves-effect waves-light" style="float: none;margin: 5px;" onClick="return Delprod()">Delete</a>
                                                                  
                                                                </div>   
                                                   </div>
                                                </div>
                                                </div>
                                            <?php }?>
                                              <?php } ?>  

                                              
                                
                                <script type="text/javascript" language="javascript">
                                
                                function Delprod()
                                {
                                  return confirm("Are Sure Want To Delete?");
                                }
                                
                                </script>
                                                      
                           
                            	</div>
                            	
                               <!-- <div class="row">
                                	<div class="col-md-4">
                                    	<div class="border-checkbox-group border-checkbox-group-danger">
                                        	<input class="border-checkbox" type="checkbox">
                                        	<label class="border-checkbox-label" for="checkbox5">Display In Hot Deals</label>
										</div>
                                    </div>
                            	</div>-->
                              <input type="hidden" value="<?php echo $transportid; ?>" name="txttransportid" >	
			
                                
                                <div>
                                <?php if(isset($_REQUEST['update'])){ ?>
                                    <button type="submit" class="btn tour-form-btn" name="btnupdate"> Update </button>
                                    <?php } else { ?>
                                    <button type="submit" class="btn tour-form-btn" name="btnsubmit">Submit</button>
                                  <?php } ?>
                                    <input type="button" class="btn " style="margin-bottom: 0px;" value="Cancel" onClick="location='transport.php'" />
                                                  
                                </div>
							</form>   
     					</div>
                	</div>
              	</div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>
<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/add.js"></script>

<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>
</body>
</html>
