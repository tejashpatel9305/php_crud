<?php

include 'connection.php';

$data = $_POST;

$count = count($_FILES["txtfile"]["name"]);

$cnt = fetchsinglecol($conn, "select max(transport_id) from  transport");
$pid = $cnt + 1;

foreach ($_FILES["txtfile"]["name"] as $i => $value) 
{
	
    move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/transport/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
    $file = date('Ymd') . $_FILES['txtfile']['name'][$i];

    $transportdate=date("Y-m-d H:i:s");
 
    $sql = "INSERT INTO `transport`(`transport_id`,`from_master_id`, `to_master_id`, `transport_img`, `transport_date`,`remarks`, `status`) VALUES('" . $pid . "','".$_REQUEST['txtfid']."','".$_REQUEST['txtmid']."','".$file."','".$transportdate."','".$_REQUEST['txtRemark']."','Y')";
    //echo $sql;
    //die();
    mysqli_query($conn, $sql);
}

function fetchsinglecol($conn, $query)
{
    $Q = mysqli_query($conn, $query) or die(mysqli_error());
    $data = mysqli_fetch_array($Q);
    return $data[0];

}
if (isset($_REQUEST['btnsubmit'])) {

    for ($i = 0; $i < count($_REQUEST['txtjtid']); $i++) 
    {

        if($_REQUEST['txttransportrate'][$i] =='')
        {
            $_REQUEST['txttransportrate'][$i] ="0";
        }
        if($_REQUEST['txttransportagentrate'][$i] =='')
        {
            $_REQUEST['txttransportagentrate'][$i] ="0";
        }
        if($_REQUEST['txtadultrate'][$i] =='')
        {
            $_REQUEST['txtadultrate'][$i] ="0";
        }
        if($_REQUEST['txtagentadultrate'][$i] =='')
        {
            $_REQUEST['txtagentadultrate'][$i] ="0";
        }
        if($_REQUEST['txtchildrate'][$i] =='')
        {
            $_REQUEST['txtchildrate'][$i] ="0";
        }
        if($_REQUEST['txtagentchildrate'][$i] =='')
        {
            $_REQUEST['txtagentchildrate'][$i] ="0";
        }

        //$trandata = mysqli_query($conn, "insert into transport_jevt(transport_jevt_id,transport_id,journey_type_id,enrout_id,vehicle_id,transfer_id,transport_rate,transport_agent_rate,adult_rate,agent_adult_rate,child_rate,agent_child_rate) values (null,'" . $pid . "','" . $_REQUEST['txtjtid'][$i] . "','" . $_REQUEST['txteid'][$i] . "','" . $_REQUEST['txtvid'][$i] . "','" . $_REQUEST['txttid'][$i] . "','" . $_REQUEST['txttransportrate'][$i] . "','" . $_REQUEST['txttransportagentrate'][$i] . "','" . $_REQUEST['txtadultrate'][$i] . "','" . $_REQUEST['txtagentadultrate'][$i] . "','" . $_REQUEST['txtchildrate'][$i] . "','" . $_REQUEST['txtagentchildrate'][$i] . "')") or die(mysqli_error($conn));
        $trandata = "insert into transport_jevt(transport_id,journey_type_id,enrout_id,vehicle_id,seat_type_id,transfer_id,transport_rate,transport_agent_rate,adult_rate,agent_adult_rate,child_rate,agent_child_rate) values ('" . $pid . "','" . $_REQUEST['txtjtid'][$i] . "','" . $_REQUEST['txteid'][$i] . "','" . $_REQUEST['txtvid'][$i] . "','" . $_REQUEST['txtstid'][$i] . "','" . $_REQUEST['txttid'][$i] . "','" . $_REQUEST['txttransportrate'][$i] . "','" . $_REQUEST['txttransportagentrate'][$i] . "','" . $_REQUEST['txtadultrate'][$i] . "','" . $_REQUEST['txtagentadultrate'][$i] . "','" . $_REQUEST['txtchildrate'][$i] . "','" . $_REQUEST['txtagentchildrate'][$i] . "')";
        mysqli_query($conn, $trandata);
       // echo $trandata;
       // die();
    }

}


if (isset($_REQUEST['btnsubmit'])) {
    for ($i = 0; $i < count($_FILES["txtfile"]["name"]); $i++) {
   
        move_uploaded_file($_FILES['txtfile']['tmp_name'][$i], "../images/transport/" . date('Ymd') . $_FILES['txtfile']['name'][$i]);
        $file = date('Ymd') . $_FILES['txtfile']['name'][$i];
    
        $data = mysqli_query($conn, "insert into transport_image(transport_image_id,transport_id,transport_sub_image) values (null,'" . $pid . "','" . $file . "')") or die(mysqli_error($conn));
        
    }

}

echo "<script>window.location='transport.php';</script>";
exit;