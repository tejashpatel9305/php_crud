<?php
session_start();

include 'connection.php';
if(!isset($_SESSION['adminame']))
{
	echo "<script>window.location='index.php';</script>";
}



function cuddata($conn,$query)
{
		$data = mysqli_query($conn,$query) or die(mysqli_error());
		return $data;
	
}

function fetchsinglecol($conn,$query)
{
	$Q = mysqli_query($conn,$query) or die(mysqli_error());
		$data = mysqli_fetch_array($Q);
		return $data[0];
	
}

function fetchsinglerow($conn,$query)
{
		$Q = mysqli_query($conn,$query);
		$data = mysqli_fetch_array($Q);
		return $data;
	
}

function fetchdata($query)
{
	$data = mysqli_query($conn,$query) or die( throwex(mysqli_error()) );
	return $data;
	
}

?>



<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>Aries Holiday</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Aries Holiday" />
<meta name="keywords" content="Aries Holiday">
<meta name="author" content="Aries Holiday"/>
<link rel="icon" href="files/assets/images/favicon.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/icon/feather/css/feather.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/font-awesome-n.min.css">
<link rel="stylesheet" href="files/bower_components/chartist/css/chartist.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="files/assets/css/widget.css">
</head>
<body>
<div id="pcoded" class="pcoded">
  <div class="pcoded-overlay-box"></div>
  <div class="pcoded-container navbar-wrapper">
  <?php 
          include 'header.php'; 
      ?>
    <div class="pcoded-main-container">
      <div class="pcoded-wrapper">
      <?php 
          include 'sidebar.php'; 
      ?>
        <div class="pcoded-content">
          <div class="page-header card">
            <div class="row align-items-end">
              <div class="col-lg-5">
                <div class="page-header-title"><img src="files/assets/images/logo-icon/admin-4.png" class="bg-c-blue">
                  	<div class="d-inline">
                    	<h5>Package Place Master</h5>
                    	<!--<span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span> -->
               		</div>
                </div>
              </div>
              <div class="col-lg-7">
                <div class="page-header-breadcrumb">
                  <ul class=" breadcrumb breadcrumb-title">
					<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#">Package </a></li>
                    <li class="breadcrumb-item"><a href="#"> Package Place  Master </a></li>

                      
		  <?php if(isset($_REQUEST['update'])){ ?>
          
           <li class="breadcrumb-item"><a href="#"> Update Package Place  Master </a></li>
           <?php } else { ?>
            
            <li class="breadcrumb-item"><a href="#"> Add Package Place  Master </a></li>
             <?php } ?>
            <?php 
            $pptitle="";
            $ppid="";

            if(isset($_REQUEST['update']))
            { 
            $result=mysqli_query($conn,"select * from  	package_place where  package_place_id='".$_REQUEST['update']."'");
            while($row=mysqli_fetch_array($result))
            {
            $ppid=$row["package_place_id"];
            $pptitle=$row["package_place_title"];
            }
            }
            ?>			
                 
				  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="pcoded-inner-content">
            <div class="main-body">
              <div class="page-wrapper">
                	<div class="page-body">
                		<div class="form-group admin-form">
                        <form method="post" enctype="multipart/form-data" id="form1">               
                        <?php
					if(isset($_REQUEST['btnsubmit']))
					{
							
							$res=mysqli_query($conn,"select * from package_place where package_place_title ='".$_REQUEST['txtppname']."'");
							if(mysqli_num_rows($res)>0)
							{
			?>
								<center><span class="label label-rouded label-danger pull-center">This Package Place name already exists</span></center>
								</br>
			<?php 
							}
							else
							{
								mysqli_query($conn,"insert into package_place values (null, '".$_REQUEST['txtppname']."','Y' )") or die(mysql_error());
			?>
								<div class="alert alert-success alert-dismissable">
            									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              									<center><?php echo "Package Place master Successfully Insert...!" ?> </center></div>
			<?php				
								/*echo "<script>window.location='Vehicle.php';</script>";*/
							}
					}
					
					
					if(isset($_REQUEST['btnupdate']))
					{
							
							mysqli_query($conn,"UPDATE package_place set  package_place_title='".$_REQUEST['txtppname']."' where  package_place_id='".$_REQUEST['txtppid']."'") or die(mysql_error());
							
							?>
								<div class="alert alert-success alert-dismissable">
            									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              									<center><?php echo "Package Place master  Successfully Update...!" ?> </center></div>
			<?php
			
								echo "<script>window.location='package_place_master.php';</script>";
   								exit;
								 
					}
			?>
			 
              <input type="hidden" value="<?php echo $ppid; ?>" name="txtppid" />
                            	<div class="row">
                                    <div class="col-md-6">
                                        <label> Place Title </label>
                                        <input class="form-control" id="package_place_title" name="txtppname" placeholder="package place title" required="required" type="text"placeholder="Enter package place title.." value="<?php echo $pptitle; ?>">
                    				</div>
                				</div>
                                
                				<!--<div class="row">	
                                    <div class="col-md-12">
                                        <label> Image </label>
                                        <input type="file" name="Image" value="" id="Image" class="form-control" multiple>
                                        <span class="field-validation-valid text-danger" data-valmsg-for="Image" data-valmsg-replace="true"></span>
                                    </div>
                				</div>-->
                                <div>
                                <?php if(isset($_REQUEST['update'])){ ?>
                <button type="submit" class="btn tour-form-btn" name="btnupdate"> Update </button>
                <?php } else { ?>
                <button type="submit" class="btn tour-form-btn" name="btnsubmit">Submit</button>
		      		<?php } ?>
                <input type="button" class="btn " style="margin-bottom: 0px;" value="Cancel" onClick="location='package_place_master.php'" />
                              
                                </div>
							</form>   
     					</div>
                	</div>
              	</div>
            </div>
          </div>
        </div>
        <div id="styleSelector"> </div>
      </div>
    </div>
  </div>
</div>
<script src="files/assets/js/email-decode.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery/js/jquery.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/popper.js/js/popper.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/bower_components/bootstrap/js/bootstrap.min.js"></script> 
<script src="files/assets/pages/waves/js/waves.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.categories.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/curvedLines.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/bower_components/chartist/js/chartist.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/amcharts.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/serial.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/pages/widget/amchart/light.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/pcoded.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/vertical/vertical-layout.min.js" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/pages/dashboard/custom-dashboard.min.js"></script> 
<script type="e58a1de310d0e6c57338bdcf-text/javascript" src="files/assets/js/script.min.js"></script> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="e58a1de310d0e6c57338bdcf-text/javascript"></script> 
<script src="files/assets/js/add.js"></script>

<script type="e58a1de310d0e6c57338bdcf-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script> 
<script src="files/assets/js/rocket-loader.min.js" data-cf-settings="e58a1de310d0e6c57338bdcf-|49" defer=""></script>
</body>
</html>
