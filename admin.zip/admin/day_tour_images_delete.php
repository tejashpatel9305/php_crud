<?php

include 'connection.php';

if (isset($_REQUEST['delete']))
{
 $deleteresult=mysqli_query($conn,"SELECT * FROM day_tour_image where day_tour_image_id = '".$_REQUEST['delete']."'");
   while($deleterow=mysqli_fetch_array($deleteresult))
   {
		$daytourimageid = $deleterow["day_tour_image_id"];
		$daytourid = $deleterow["day_tour_id"];

   }
   unlink("../images/daytour/".$_REQUEST['img']);
   mysqli_query($conn,"delete from day_tour_image where day_tour_image_id ='".$_REQUEST['delete']."'");

}
  //echo "<NOSCRIPT><a href='edit_tourpackages.php?update='".$tourpackagesid."'>Successfully Delete. Click here if you are not redirected.</a></NOSCRIPT>";

//echo "<script>window.location='edit_tourpackages.php?update='".$tourpackagesid."'';</script>;
header('Location: edit_daytour.php?update='.$daytourid);

	exit;
